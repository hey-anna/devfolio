import { useMutation, useQueryClient } from "@tanstack/react-query";
import client from "../../api/commonApi";

const addGreenBean = async (formData) => {
  return client.post("/bean/create", formData);
};

export const useAddGreenBeanMutation = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: addGreenBean,
    onSuccess: () => {
      console.log("#@#@ Green bean information added successfully!");
      queryClient.invalidateQueries(["green-beans"]);
    },
    onError: (error) => {
      console.error("#@#@ Failed to add green bean information:", error);
    },
  });
};
