// import { useQuery } from "@tanstack/react-query";
// // import api from "../utils/api";
// import client from "../../api/commonApi";

// const fetchOriginInfo = () => {
//   return client.post(`/country`, {});
// };

// export const useOriginInfoQuery = () => {
//   return useQuery({
//     queryKey: ["origin-info"],
//     queryFn: fetchOriginInfo,
//     select: (result) => result.data.data,
//     staleTime: 300000, // 5분
//   });
// };
