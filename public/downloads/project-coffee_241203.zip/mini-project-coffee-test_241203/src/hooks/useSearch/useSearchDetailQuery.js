import { useQuery } from "@tanstack/react-query";
import client from "../../api/commonApi";

const fetchPlatformDetail = (coffee_key_id) => {
  return client.get(`/bean/${coffee_key_id}`, { coffee_key_id });
};

export const useSearchDetailQuery = (coffee_key_id) => {
  return useQuery({
    queryKey: ["bean-detail", coffee_key_id],
    queryFn: () => fetchPlatformDetail(coffee_key_id),
    select: (result) => result.data.data,
    staleTime: 300000,
  });
};
