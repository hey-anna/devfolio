import { useQuery } from "@tanstack/react-query";
import client from "../../api/commonApi";

const fetchSearch = ({ keyword, categoryKey, categoryValue, pageType }) => {
  const baseUrl = `/bean`;
  const body = {
    ...(pageType === "searchPage" ? { CoffeeName: keyword } : keyword),
    ...(categoryKey && { [categoryKey]: categoryValue }),
  };
  console.log("##Sending search request to server with body:", body);
  return client.post(baseUrl, body);
};

export const useSearchQuery = ({
  keyword,
  categoryKey,
  categoryValue,
  pageType,
}) => {
  console.log("##Keyword received in useSearchQuery:", keyword);
  return useQuery({
    queryKey: ["green-beans", { keyword, categoryKey, categoryValue }],
    queryFn: () =>
      fetchSearch({ keyword, categoryKey, categoryValue, pageType }),
    select: (response) => {
      console.log("## search API response data:", response.data.data);
      return response.data.data || [];
    },
    onError: (error) => {
      console.error("Error fetching contracts:", error);
    },
  });
};
