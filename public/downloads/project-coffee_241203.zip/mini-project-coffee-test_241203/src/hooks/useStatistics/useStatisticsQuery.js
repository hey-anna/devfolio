import { useQuery } from "@tanstack/react-query";
import client from "../../api/commonApi";

const fetchStatisticsData = () => {
  return client.get(`/statistics`);
};

export const useStatisticsQuery = (options = {}) => {
  return useQuery({
    queryKey: ["statistics-data"],
    queryFn: fetchStatisticsData,
    select: (result) => result.data.data,
    ...options,
  });
};
