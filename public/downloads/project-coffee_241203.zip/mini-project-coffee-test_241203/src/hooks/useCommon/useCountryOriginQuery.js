import { useQuery } from "@tanstack/react-query";
import client from "../../api/commonApi";
const fetchCountryOrigin = ({ countryNameEng }) => {
  const baseUrl = `/country`;
  const body = {
    CountryNameEng: countryNameEng,
  };
  return client.post(baseUrl, body);
};

export const useCountryOriginQuery = (countryNameEng, triggered) => {
  return useQuery({
    queryKey: ["country-of-origin", countryNameEng],
    queryFn: () => fetchCountryOrigin({ countryNameEng }),
    select: (result) => result.data.data,
    staleTime: 300000,
    enabled: triggered,
  });
};
