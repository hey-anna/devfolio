import React from "react";
import Header from "./layouts/Header";
import Footer from "./layouts/Footer";
import { Outlet, useLocation } from "react-router-dom";
import { MypageDialog } from "./layouts/mypage/MypageDialog";

function App() {
  const location = useLocation();
  return (
    <>
      <Header />
      <Outlet />
      {location.pathname === "/mypage" && <MypageDialog />}
      <Footer />
    </>
  );
}

export default App;
