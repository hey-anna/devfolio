import { ReactComponent as MypageDialogIcon01 } from "../assets/icons/mypageIcons/mypage_dialog_icon_01.svg";
import MenuBookIcon from "@mui/icons-material/MenuBook";

export const MypageDialogActions = [
  {
    icon: <MenuBookIcon sx={{ color: "#333" }} />,
    name: "등록후절차",
    modal: "PostRegSteps",
  },
  {
    icon: <MypageDialogIcon01 style={{ color: "#333" }} />,
    name: "생두등록",
    modal: "GreenBeanReg",
  },
];
