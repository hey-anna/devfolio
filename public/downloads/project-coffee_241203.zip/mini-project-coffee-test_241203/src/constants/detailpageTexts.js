export const barGraphInfo = [
  {
    item: "유기산\nOrganic acids",
    info: "산미에 관여한다. 로스팅 시에 매 대부분 분해되지만, 일부는 남아 커피에 산도에 영향을 준다.",
  },
  {
    item: "수크로스\nSucrose",
    info: "열 분해시 다양한 향미를 만들어 낸다.",
  },
  {
    item: "단당류\nMono sugar",
    info: "향미, 특히 단 아로마를 만드는 데 기여한다.",
  },
  {
    item: "다당류\nPoly sugar",
    info: "열 분해시 다당류의 일부가 분해되면서 단당류가 생성되어 간접적으로 커피의 향미에 영향을 줄 수 있다. 남은 수용성 다당류는 일부가 물에 추출되어 커피의 바디감에 기여한다.",
  },
  { item: "지질\nLipid", info: "생성된 향미를 일정하게 유지하는 역할을 한다." },
  {
    item: "단백질\nProtein",
    info: "아미노산의 복합체로, 로스팅시 다양한 향미 화합물을 생성한다.",
  },
  {
    item: "디테르펜\nDiterpene",
    info: "로스팅시 아미노산과 결합하여 과일 몰트향의 향미에 관여한다.",
  },
  {
    item: "트리고넬린\nTrigonelline",
    info: "열에 분해되어 더 향미에 관여한다.",
  },
  { item: "클로로겐산\nChlorogenic acids", info: "쓴 맛에 관여하는 성분이다." },
  { item: "카페인\nCaffeine", info: "쓴 맛에 관여하는 성분이다." },
  {
    item: "카페인 유도체\nCaffeine-sub",
    info: "카페인과 유사한 쓴맛에 관여하는 물질로 테오브로민과 테오필린 등 존재한다.",
  },
  {
    item: "수분\nWater",
    info: "생두의 기존 수분 함량인 자유수와 분자와 강하게 결합하고 있는 물의 결합수가 합쳐진 예측값이다.",
  },
];
