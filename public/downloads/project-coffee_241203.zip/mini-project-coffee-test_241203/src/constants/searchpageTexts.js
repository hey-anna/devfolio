export const categories = {
  아라비카: { key: "BeanVariety", value: "아라비카" }, // 생두 품종
  콜롬비아: { key: "ProductionCountryCode", value: "CO" }, // 원산지
  에티오피아: { key: "ProductionCountryCode", value: "ET" }, // 원산지
  Washed: { key: "ProcessingCode", value: "PRCS01" }, // 가공법
  Honey: { key: "ProcessingCode", value: "PRCS02" },
  Natural: { key: "ProcessingCode", value: "PRCS03" },
  Anaerobic: { key: "ProcessingCode", value: "PRCS04" },
};

export const processingTypes = {
  PRCS01: "Washed",
  PRCS02: "Honey",
  PRCS03: "Natural",
  PRCS04: "Anaerobic",
};
// coffeeInfoData 임시 데이터 > 실서버 생기면 삭제하기 > 외부에서 작업할때 혹시필요할까바
export const greenBeansData = [
  {
    CoffeeCode: "d063db2d-4fe4-41f3-889a-556dea673987",
    CoffeeKey: "d063db2d-4fe4-41f3-889a-556dea673987",
    CoffeeName: "Ethiopia Sidama Bona Zuria Bare Washed G1", // 생두타이틀2
    BeanVariety: "Sidama, Bona Zuria, Bare, Sidama, Bona Zuria, Bare", // 생두품종3
    ProductionCountryCode: "ET", // 원산지5
    ProductionYear: "2021", // 생산년도8
    Altitude: "2000-2200",
    StockDate: "2022-05-01",
    ProcessingCode: "PRCS01", // 가공방법4
    Company: "Pebble Coffee", // 생산회사6
    Weight: "60",
    Farm: "Bona Farm", // 생산농장7
    // 이미지1
    ImageUrl:
      "https://media.istockphoto.com/id/2164909312/ko/%EC%82%AC%EC%A7%84/%EC%BB%A4%ED%94%BC-%EC%9B%90%EB%91%90-%EB%A1%9C%EC%8A%A4%ED%8C%85-%EC%A0%9C%ED%92%88-%EC%88%98%EC%B6%9C-%EB%98%90%EB%8A%94-%ED%92%88%EC%A7%88-%EB%B3%B4%EC%A6%9D%EC%9D%84-%EC%9C%84%ED%95%9C-%EC%84%B1%EB%B6%84%EC%9D%B4-%EC%9E%88%EB%8A%94-%EA%B8%B0%EA%B3%84-%EB%B0%8F-%EA%B3%B5%EC%9E%A5-%EB%B9%84%EC%96%B4-%EC%9E%88%EB%8A%94-%ED%8F%89%EB%A9%B4%EB%8F%84-%EB%B0%8F-%ED%94%84%EB%A6%AC%EB%AF%B8%EC%97%84-%EC%97%90%EC%8A%A4%ED%94%84%EB%A0%88%EC%86%8C-%EC%B9%B4%ED%8E%98%EC%9D%B8-%EB%98%90%EB%8A%94-%EC%8B%A0%EC%84%A0%ED%95%9C-%EB%B8%94%EB%A0%8C%EB%93%9C%EB%A5%BC-%EC%9C%84%ED%95%9C-%EC%9E%A5%EB%B9%84%EB%A1%9C-%EC%A0%9C%EC%A1%B0.jpg?s=1024x1024&w=is&k=20&c=U4mS4xAItRN1ml8zvDRJ1becEN0UEoA0KbnVLqENKdA=",
  },
  {
    CoffeeCode: "d064ee3e-5f4b-48d3-b5b1-8b0ead298a91",
    CoffeeKey: "d064ee3e-5f4b-48d3-b5b1-8b0ead298a91",
    CoffeeName: "Kenya Nyeri Gichatha-ini AA",
    BeanVariety: "SL28, SL34",
    ProductionCountryCode: "KE",
    ProductionYear: "2022",
    Altitude: "1700-1800",
    StockDate: "2022-08-10",
    ProcessingCode: "PRCS02",
    Company: "Bean Vault Coffee",
    Weight: "50",
    Farm: "Gichatha-ini",
    ImageUrl:
      "https://media.istockphoto.com/id/2164909312/ko/%EC%82%AC%EC%A7%84/%EC%BB%A4%ED%94%BC-%EC%9B%90%EB%91%90-%EB%A1%9C%EC%8A%A4%ED%8C%85-%EC%A0%9C%ED%92%88-%EC%88%98%EC%B6%9C-%EB%98%90%EB%8A%94-%ED%92%88%EC%A7%88-%EB%B3%B4%EC%A6%9D%EC%9D%84-%EC%9C%84%ED%95%9C-%EC%84%B1%EB%B6%84%EC%9D%B4-%EC%9E%88%EB%8A%94-%EA%B8%B0%EA%B3%84-%EB%B0%8F-%EA%B3%B5%EC%9E%A5-%EB%B9%84%EC%96%B4-%EC%9E%88%EB%8A%94-%ED%8F%89%EB%A9%B4%EB%8F%84-%EB%B0%8F-%ED%94%84%EB%A6%AC%EB%AF%B8%EC%97%84-%EC%97%90%EC%8A%A4%ED%94%84%EB%A0%88%EC%86%8C-%EC%B9%B4%ED%8E%98%EC%9D%B8-%EB%98%90%EB%8A%94-%EC%8B%A0%EC%84%A0%ED%95%9C-%EB%B8%94%EB%A0%8C%EB%93%9C%EB%A5%BC-%EC%9C%84%ED%95%9C-%EC%9E%A5%EB%B9%84%EB%A1%9C-%EC%A0%9C%EC%A1%B0.jpg?s=1024x1024&w=is&k=20&c=U4mS4xAItRN1ml8zvDRJ1becEN0UEoA0KbnVLqENKdA=",
  },
  {
    CoffeeCode: "f065de4f-6c34-4bda-a733-3df22b6f1234",
    CoffeeKey: "f065de4f-6c34-4bda-a733-3df22b6f1234",
    CoffeeName: "Colombia Huila Excelso EP",
    BeanVariety: "Caturra, Castillo",
    ProductionCountryCode: "CO",
    ProductionYear: "2021",
    Altitude: "1500-1800",
    StockDate: "2022-03-15",
    ProcessingCode: "PRCS03",
    Company: "Highlands Coffee",
    Weight: "70",
    Farm: "Huila Farm",
    ImageUrl:
      "https://media.istockphoto.com/id/2164909312/ko/%EC%82%AC%EC%A7%84/%EC%BB%A4%ED%94%BC-%EC%9B%90%EB%91%90-%EB%A1%9C%EC%8A%A4%ED%8C%85-%EC%A0%9C%ED%92%88-%EC%88%98%EC%B6%9C-%EB%98%90%EB%8A%94-%ED%92%88%EC%A7%88-%EB%B3%B4%EC%A6%9D%EC%9D%84-%EC%9C%84%ED%95%9C-%EC%84%B1%EB%B6%84%EC%9D%B4-%EC%9E%88%EB%8A%94-%EA%B8%B0%EA%B3%84-%EB%B0%8F-%EA%B3%B5%EC%9E%A5-%EB%B9%84%EC%96%B4-%EC%9E%88%EB%8A%94-%ED%8F%89%EB%A9%B4%EB%8F%84-%EB%B0%8F-%ED%94%84%EB%A6%AC%EB%AF%B8%EC%97%84-%EC%97%90%EC%8A%A4%ED%94%84%EB%A0%88%EC%86%8C-%EC%B9%B4%ED%8E%98%EC%9D%B8-%EB%98%90%EB%8A%94-%EC%8B%A0%EC%84%A0%ED%95%9C-%EB%B8%94%EB%A0%8C%EB%93%9C%EB%A5%BC-%EC%9C%84%ED%95%9C-%EC%9E%A5%EB%B9%84%EB%A1%9C-%EC%A0%9C%EC%A1%B0.jpg?s=1024x1024&w=is&k=20&c=U4mS4xAItRN1ml8zvDRJ1becEN0UEoA0KbnVLqENKdA=",
  },
  {
    CoffeeCode: "a066ee5g-7d45-4dbf-8451-4e4ead5a2567",
    CoffeeKey: "a066ee5g-7d45-4dbf-8451-4e4ead5a2567",
    CoffeeName: "Guatemala Antigua Pulcal Inteligente Washed",
    BeanVariety: "Bourbon, Caturra",
    ProductionCountryCode: "GT",
    ProductionYear: "2022",
    Altitude: "1800-2000",
    StockDate: "2022-09-20",
    ProcessingCode: "PRCS04",
    Company: "Antigua Coffee House",
    Weight: "55",
    Farm: "Pulcal",
    ImageUrl:
      "https://media.istockphoto.com/id/2164909312/ko/%EC%82%AC%EC%A7%84/%EC%BB%A4%ED%94%BC-%EC%9B%90%EB%91%90-%EB%A1%9C%EC%8A%A4%ED%8C%85-%EC%A0%9C%ED%92%88-%EC%88%98%EC%B6%9C-%EB%98%90%EB%8A%94-%ED%92%88%EC%A7%88-%EB%B3%B4%EC%A6%9D%EC%9D%84-%EC%9C%84%ED%95%9C-%EC%84%B1%EB%B6%84%EC%9D%B4-%EC%9E%88%EB%8A%94-%EA%B8%B0%EA%B3%84-%EB%B0%8F-%EA%B3%B5%EC%9E%A5-%EB%B9%84%EC%96%B4-%EC%9E%88%EB%8A%94-%ED%8F%89%EB%A9%B4%EB%8F%84-%EB%B0%8F-%ED%94%84%EB%A6%AC%EB%AF%B8%EC%97%84-%EC%97%90%EC%8A%A4%ED%94%84%EB%A0%88%EC%86%8C-%EC%B9%B4%ED%8E%98%EC%9D%B8-%EB%98%90%EB%8A%94-%EC%8B%A0%EC%84%A0%ED%95%9C-%EB%B8%94%EB%A0%8C%EB%93%9C%EB%A5%BC-%EC%9C%84%ED%95%9C-%EC%9E%A5%EB%B9%84%EB%A1%9C-%EC%A0%9C%EC%A1%B0.jpg?s=1024x1024&w=is&k=20&c=U4mS4xAItRN1ml8zvDRJ1becEN0UEoA0KbnVLqENKdA=",
  },
  {
    CoffeeCode: "b077ff6h-8f56-4ece-8622-5f5ffdb34789",
    CoffeeKey: "b077ff6h-8f56-4ece-8622-5f5ffdb34789",
    CoffeeName: "Brazil Cerrado Mineiro Natural",
    BeanVariety: "Mundo Novo, Catuai",
    ProductionCountryCode: "BR",
    ProductionYear: "2021",
    Altitude: "1100-1300",
    StockDate: "2022-10-05",
    ProcessingCode: "PRCS05",
    Company: "Bravo Brewer",
    Weight: "80",
    Farm: "Cerrado",
    ImageUrl:
      "https://media.istockphoto.com/id/2164909312/ko/%EC%82%AC%EC%A7%84/%EC%BB%A4%ED%94%BC-%EC%9B%90%EB%91%90-%EB%A1%9C%EC%8A%A4%ED%8C%85-%EC%A0%9C%ED%92%88-%EC%88%98%EC%B6%9C-%EB%98%90%EB%8A%94-%ED%92%88%EC%A7%88-%EB%B3%B4%EC%A6%9D%EC%9D%84-%EC%9C%84%ED%95%9C-%EC%84%B1%EB%B6%84%EC%9D%B4-%EC%9E%88%EB%8A%94-%EA%B8%B0%EA%B3%84-%EB%B0%8F-%EA%B3%B5%EC%9E%A5-%EB%B9%84%EC%96%B4-%EC%9E%88%EB%8A%94-%ED%8F%89%EB%A9%B4%EB%8F%84-%EB%B0%8F-%ED%94%84%EB%A6%AC%EB%AF%B8%EC%97%84-%EC%97%90%EC%8A%A4%ED%94%84%EB%A0%88%EC%86%8C-%EC%B9%B4%ED%8E%98%EC%9D%B8-%EB%98%90%EB%8A%94-%EC%8B%A0%EC%84%A0%ED%95%9C-%EB%B8%94%EB%A0%8C%EB%93%9C%EB%A5%BC-%EC%9C%84%ED%95%9C-%EC%9E%A5%EB%B9%84%EB%A1%9C-%EC%A0%9C%EC%A1%B0.jpg?s=1024x1024&w=is&k=20&c=U4mS4xAItRN1ml8zvDRJ1becEN0UEoA0KbnVLqENKdA=",
  },
  {
    CoffeeCode: "c088gg7i-9g67-4fde-9733-6g6gge6b458a",
    CoffeeKey: "c088gg7i-9g67-4fde-9733-6g6gge6b458a",
    CoffeeName: "Indonesia Sumatra Mandheling G1",
    BeanVariety: "Ateng, Jember",
    ProductionCountryCode: "ID",
    ProductionYear: "2022",
    Altitude: "1200-1500",
    StockDate: "2022-11-12",
    ProcessingCode: "PRCS06",
    Company: "Island Joe Coffee",
    Weight: "75",
    Farm: "Mandheling",
    ImageUrl:
      "https://media.istockphoto.com/id/2164909312/ko/%EC%82%AC%EC%A7%84/%EC%BB%A4%ED%94%BC-%EC%9B%90%EB%91%90-%EB%A1%9C%EC%8A%A4%ED%8C%85-%EC%A0%9C%ED%92%88-%EC%88%98%EC%B6%9C-%EB%98%90%EB%8A%94-%ED%92%88%EC%A7%88-%EB%B3%B4%EC%A6%9D%EC%9D%84-%EC%9C%84%ED%95%9C-%EC%84%B1%EB%B6%84%EC%9D%B4-%EC%9E%88%EB%8A%94-%EA%B8%B0%EA%B3%84-%EB%B0%8F-%EA%B3%B5%EC%9E%A5-%EB%B9%84%EC%96%B4-%EC%9E%88%EB%8A%94-%ED%8F%89%EB%A9%B4%EB%8F%84-%EB%B0%8F-%ED%94%84%EB%A6%AC%EB%AF%B8%EC%97%84-%EC%97%90%EC%8A%A4%ED%94%84%EB%A0%88%EC%86%8C-%EC%B9%B4%ED%8E%98%EC%9D%B8-%EB%98%90%EB%8A%94-%EC%8B%A0%EC%84%A0%ED%95%9C-%EB%B8%94%EB%A0%8C%EB%93%9C%EB%A5%BC-%EC%9C%84%ED%95%9C-%EC%9E%A5%EB%B9%84%EB%A1%9C-%EC%A0%9C%EC%A1%B0.jpg?s=1024x1024&w=is&k=20&c=U4mS4xAItRN1ml8zvDRJ1becEN0UEoA0KbnVLqENKdA=",
  },
  {
    CoffeeCode: "d099hh8j-ah78-4fg9-9844-7h7hhj7c569b",
    CoffeeKey: "d099hh8j-ah78-4fg9-9844-7h7hhj7c569b",
    CoffeeName: "Yemen Mocha Mattari",
    BeanVariety: "Heirloom",
    ProductionCountryCode: "YE",
    ProductionYear: "2022",
    Altitude: "2100-2300",
    StockDate: "2022-12-25",
    ProcessingCode: "PRCS07",
    Company: "Mocha Joe's",
    Weight: "65",
    Farm: "Mattari",
    ImageUrl:
      "https://media.istockphoto.com/id/2164909312/ko/%EC%82%AC%EC%A7%84/%EC%BB%A4%ED%94%BC-%EC%9B%90%EB%91%90-%EB%A1%9C%EC%8A%A4%ED%8C%85-%EC%A0%9C%ED%92%88-%EC%88%98%EC%B6%9C-%EB%98%90%EB%8A%94-%ED%92%88%EC%A7%88-%EB%B3%B4%EC%A6%9D%EC%9D%84-%EC%9C%84%ED%95%9C-%EC%84%B1%EB%B6%84%EC%9D%B4-%EC%9E%88%EB%8A%94-%EA%B8%B0%EA%B3%84-%EB%B0%8F-%EA%B3%B5%EC%9E%A5-%EB%B9%84%EC%96%B4-%EC%9E%88%EB%8A%94-%ED%8F%89%EB%A9%B4%EB%8F%84-%EB%B0%8F-%ED%94%84%EB%A6%AC%EB%AF%B8%EC%97%84-%EC%97%90%EC%8A%A4%ED%94%84%EB%A0%88%EC%86%8C-%EC%B9%B4%ED%8E%98%EC%9D%B8-%EB%98%90%EB%8A%94-%EC%8B%A0%EC%84%A0%ED%95%9C-%EB%B8%94%EB%A0%8C%EB%93%9C%EB%A5%BC-%EC%9C%84%ED%95%9C-%EC%9E%A5%EB%B9%84%EB%A1%9C-%EC%A0%9C%EC%A1%B0.jpg?s=1024x1024&w=is&k=20&c=U4mS4xAItRN1ml8zvDRJ1becEN0UEoA0KbnVLqENKdA=",
  },
  {
    CoffeeCode: "e100ii9k-bi89-4gh0-aa55-8i8ikk8d670c",
    CoffeeKey: "e100ii9k-bi89-4gh0-aa55-8i8ikk8d670c",
    CoffeeName: "Vietnam Da Lat Washed Arabica",
    BeanVariety: "Catimor",
    ProductionCountryCode: "VN",
    ProductionYear: "2021",
    Altitude: "1500-1700",
    StockDate: "2022-01-30",
    ProcessingCode: "PRCS08",
    Company: "Da Lat Highlands Coffee",
    Weight: "50",
    Farm: "Da Lat",
    ImageUrl:
      "https://media.istockphoto.com/id/2164909312/ko/%EC%82%AC%EC%A7%84/%EC%BB%A4%ED%94%BC-%EC%9B%90%EB%91%90-%EB%A1%9C%EC%8A%A4%ED%8C%85-%EC%A0%9C%ED%92%88-%EC%88%98%EC%B6%9C-%EB%98%90%EB%8A%94-%ED%92%88%EC%A7%88-%EB%B3%B4%EC%A6%9D%EC%9D%84-%EC%9C%84%ED%95%9C-%EC%84%B1%EB%B6%84%EC%9D%B4-%EC%9E%88%EB%8A%94-%EA%B8%B0%EA%B3%84-%EB%B0%8F-%EA%B3%B5%EC%9E%A5-%EB%B9%84%EC%96%B4-%EC%9E%88%EB%8A%94-%ED%8F%89%EB%A9%B4%EB%8F%84-%EB%B0%8F-%ED%94%84%EB%A6%AC%EB%AF%B8%EC%97%84-%EC%97%90%EC%8A%A4%ED%94%84%EB%A0%88%EC%86%8C-%EC%B9%B4%ED%8E%98%EC%9D%B8-%EB%98%90%EB%8A%94-%EC%8B%A0%EC%84%A0%ED%95%9C-%EB%B8%94%EB%A0%8C%EB%93%9C%EB%A5%BC-%EC%9C%84%ED%95%9C-%EC%9E%A5%EB%B9%84%EB%A1%9C-%EC%A0%9C%EC%A1%B0.jpg?s=1024x1024&w=is&k=20&c=U4mS4xAItRN1ml8zvDRJ1becEN0UEoA0KbnVLqENKdA=",
  },
  {
    CoffeeCode: "f111jj0l-cj90-5hi1-bb66-9j9jll9e781d",
    CoffeeKey: "f111jj0l-cj90-5hi1-bb66-9j9jll9e781d",
    CoffeeName: "Ethiopia Yirgacheffe Kochere",
    BeanVariety: "Heirloom",
    ProductionCountryCode: "ET",
    ProductionYear: "2022",
    Altitude: "1800-2200",
    StockDate: "2022-02-14",
    ProcessingCode: "PRCS09",
    Company: "Peak Roasters",
    Weight: "60",
    Farm: "Kochere",
    ImageUrl:
      "https://media.istockphoto.com/id/2164909312/ko/%EC%82%AC%EC%A7%84/%EC%BB%A4%ED%94%BC-%EC%9B%90%EB%91%90-%EB%A1%9C%EC%8A%A4%ED%8C%85-%EC%A0%9C%ED%92%88-%EC%88%98%EC%B6%9C-%EB%98%90%EB%8A%94-%ED%92%88%EC%A7%88-%EB%B3%B4%EC%A6%9D%EC%9D%84-%EC%9C%84%ED%95%9C-%EC%84%B1%EB%B6%84%EC%9D%B4-%EC%9E%88%EB%8A%94-%EA%B8%B0%EA%B3%84-%EB%B0%8F-%EA%B3%B5%EC%9E%A5-%EB%B9%84%EC%96%B4-%EC%9E%88%EB%8A%94-%ED%8F%89%EB%A9%B4%EB%8F%84-%EB%B0%8F-%ED%94%84%EB%A6%AC%EB%AF%B8%EC%97%84-%EC%97%90%EC%8A%A4%ED%94%84%EB%A0%88%EC%86%8C-%EC%B9%B4%ED%8E%98%EC%9D%B8-%EB%98%90%EB%8A%94-%EC%8B%A0%EC%84%A0%ED%95%9C-%EB%B8%94%EB%A0%8C%EB%93%9C%EB%A5%BC-%EC%9C%84%ED%95%9C-%EC%9E%A5%EB%B9%84%EB%A1%9C-%EC%A0%9C%EC%A1%B0.jpg?s=1024x1024&w=is&k=20&c=U4mS4xAItRN1ml8zvDRJ1becEN0UEoA0KbnVLqENKdA=",
  },
  {
    CoffeeCode: "g122kk1m-dk01-6ij2-cc77-k0klm0af892e",
    CoffeeKey: "g122kk1m-dk01-6ij2-cc77-k0klm0af892e",
    CoffeeName: "Panama Boquete Geisha",
    BeanVariety: "Geisha",
    ProductionCountryCode: "PA",
    ProductionYear: "2022",
    Altitude: "1500-1700",
    StockDate: "2022-06-18",
    ProcessingCode: "PRCS10",
    Company: "Boquete Blends",
    Weight: "55",
    Farm: "Boquete",
    ImageUrl:
      "https://media.istockphoto.com/id/2164909312/ko/%EC%82%AC%EC%A7%84/%EC%BB%A4%ED%94%BC-%EC%9B%90%EB%91%90-%EB%A1%9C%EC%8A%A4%ED%8C%85-%EC%A0%9C%ED%92%88-%EC%88%98%EC%B6%9C-%EB%98%90%EB%8A%94-%ED%92%88%EC%A7%88-%EB%B3%B4%EC%A6%9D%EC%9D%84-%EC%9C%84%ED%95%9C-%EC%84%B1%EB%B6%84%EC%9D%B4-%EC%9E%88%EB%8A%94-%EA%B8%B0%EA%B3%84-%EB%B0%8F-%EA%B3%B5%EC%9E%A5-%EB%B9%84%EC%96%B4-%EC%9E%88%EB%8A%94-%ED%8F%89%EB%A9%B4%EB%8F%84-%EB%B0%8F-%ED%94%84%EB%A6%AC%EB%AF%B8%EC%97%84-%EC%97%90%EC%8A%A4%ED%94%84%EB%A0%88%EC%86%8C-%EC%B9%B4%ED%8E%98%EC%9D%B8-%EB%98%90%EB%8A%94-%EC%8B%A0%EC%84%A0%ED%95%9C-%EB%B8%94%EB%A0%8C%EB%93%9C%EB%A5%BC-%EC%9C%84%ED%95%9C-%EC%9E%A5%EB%B9%84%EB%A1%9C-%EC%A0%9C%EC%A1%B0.jpg?s=1024x1024&w=is&k=20&c=U4mS4xAItRN1ml8zvDRJ1becEN0UEoA0KbnVLqENKdA=",
  },
];
