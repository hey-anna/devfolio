export const graphCardtexts = (data) => [
  {
    title: "등록 생두 건수",
    date: data?.BeanCount || "0",
    description: "건",
  },
  {
    title: "누적 분석 건수",
    date: data?.AnalysisCount || "0",
    description: "건",
  },
  {
    title: "최근 1개월 등록 생두",
    date: data?.BeanMonth || "0",
    description: "건",
  },
  {
    title: "최근 6개월 분석 생두",
    date: data?.AnalysisSixMonth || "0",
    description: "건",
  },
  {
    title: "최근 생산 제품 건수",
    date: data?.CoffeeCount || "0",
    description: "건",
  },
];
