import intro_fourth_icon_01 from "../assets/icons/introIcons/intro_fourth_icon_01.svg";
import intro_fourth_icon_02 from "../assets/icons/introIcons/intro_fourth_icon_02.svg";
import intro_fourth_icon_03 from "../assets/icons/introIcons/intro_fourth_icon_03.svg";
import intro_fifth_icon_01 from "../assets/icons/introIcons/intro_fifth_icon_01.svg";
import intro_fifth_icon_02 from "../assets/icons/introIcons/intro_fifth_icon_02.svg";
import intro_fifth_icon_03 from "../assets/icons/introIcons/intro_fifth_icon_03.svg";

export const intro_fourth_texts = [
  {
    title: "생두",
    description: "먼저 생두 200g의 샘플을 보내주세요.",
    image: intro_fourth_icon_01,
    imageLabel: "생두200g 아이콘",
  },
  {
    title: "AI와 데이터 사이언스",
    description:
      "에그스톤이 사용하는 AI와 데이터 기반 기술은 패턴인식과 비지도학습 최적화 계산으로 감춰져 있던 생두의 특성을 보여줍니다.",
    image: intro_fourth_icon_02,
    imageLabel: "AI와데이터사이언스 아이콘",
  },
  {
    title: "결과",
    description:
      "결과는 각각커피 생두가 가진 잠재적인 특성을 보여줍니다. 이는 생두를 보다 객관적이고 정확하게 이해할 수 있도록 도와줍니다.",
    image: intro_fourth_icon_03,
    imageLabel: "결과 아이콘",
  },
];

export const intro_fifth_texts = [
  {
    title: "맛의 잠재성",
    description:
      "오각형의 그래프는 생두의 품질과 맛에 관련된 다섯 가지의 맛의 잠재력(산미, 단맛, 바디감, 쓴맛, 아로마 잠재성)을 나나탭니다.",
    image: intro_fifth_icon_01,
    imageLabel: "맛의 잠재성 아이콘",
  },
  {
    title: "아로마 잠재성",
    description:
      "아로마 포텐셜 그래프는 생두가 가진 고유한 아로마 잠재성에 관여하는 분석을 나타냅니다.",
    image: intro_fifth_icon_02,
    imageLabel: "아로마 잠재성 아이콘",
  },
  {
    title: "바 그래프",
    description:
      "바 그래프는 생두의 품질과 맛에 관련된 생두 속 화학 성분을 나타냅니다. 바 그래프를 통해 16가지의 화학 성분을 한 번에 확인하고 비교할 수 있습니다.",
    image: intro_fifth_icon_03,
    imageLabel: "바 그래프 아이콘",
  },
];
