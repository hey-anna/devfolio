import React from "react";
import {
  Button,
  Stack,
  Box,
  Grid2,
  Typography,
  Container,
  Divider,
} from "@mui/material";
import { styled } from "@mui/material/styles";
import StatisticsCard from "../layouts/statisticspage/StatisticsCard";

import { useStatisticsQuery } from "../hooks/useStatistics/useStatisticsQuery";
import { graphCardtexts } from "../constants/statisticsTexts";

const TypographySx = styled(Typography)(({ theme }) => ({
  ...theme.typography.h5,
  textAlign: "left",
  position: "absolute",
  left: "10%",
  top: "12%",
}));

const StatisticsPage = () => {
  const { data: statisticsData, isLoading, isError } = useStatisticsQuery({});

  console.log("##statisticsData", statisticsData);
  const cardsData = graphCardtexts(statisticsData);
  return (
    <>
      <Box
        sx={{
          pb: 6,
        }}
      >
        <Container
          sx={{
            pt: 8,
            pb: 6,
          }}
          maxWidth="lg"
        >
          <Typography component="h2" variant="h3" sx={{ mb: 8 }}>
            데이터 통계
          </Typography>
          <Box sx={{ flexGrow: 1 }}>
            <Grid2
              container
              spacing={4}
              sx={{ justifyContent: "flex-end", marginBottom: 4 }}
            >
              <StatisticsCard card={cardsData[0]} />
              <StatisticsCard card={cardsData[1]} />
            </Grid2>
            <Grid2 container spacing={4} sx={{ justifyContent: "flex-end" }}>
              <StatisticsCard card={cardsData[2]} />
              <StatisticsCard card={cardsData[3]} />
              <StatisticsCard card={cardsData[4]} />
            </Grid2>
          </Box>
        </Container>
      </Box>
    </>
  );
};

export default StatisticsPage;
