import React, { useState, useEffect } from "react";
import { styled } from "@mui/material/styles";
import {
  Button,
  Stack,
  Box,
  Grid2,
  Typography,
  Container,
  Divider,
} from "@mui/material";

import { intro_fourth_texts } from "../constants/intropageTexts";
import { intro_fifth_texts } from "../constants/intropageTexts";
import intropageStyles from "../assets/styles/views/intropage.module.css";
import intro_section01 from "../assets/images/introImages/intro_section01.svg";
import intro_section02_a from "../assets/images/introImages/intro_section02_a.svg";
import intro_section02_b from "../assets/images/introImages/intro_section02_b.svg";
import intro_section03 from "../assets/images/introImages/intro_section03.svg";
import IntroQuickNav from "../layouts/intropage/IntroQuickNav";

const InBox = styled(Box)(({ theme, customStyle }) => ({
  width: "100%",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  mb: 12,
  ...customStyle,
  "& img": {
    width: "85%",
    height: "auto",
    display: "flex",
    justifyContent: "center",
    paddingLeft: "2%",
  },
}));
const sections = [
  { id: "businessGoals", label: "사업추진 목표" },
  { id: "blockchainLogistics", label: "블록체인 기반 물류" },
  { id: "coffeeAnalysis", label: "커피분석 방법" },
  { id: "blockchainCoffee", label: "블록체인과 커피 이해하기" },
];
const IntroPage = () => {
  const [showQuickNav, setShowQuickNav] = useState(false);
  const [activeSection, setActiveSection] = useState(null);

  useEffect(() => {
    const handleScroll = () => {
      const position = window.pageYOffset;
      setShowQuickNav(position > 300);
    };

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveSection(entry.target.id);
          }
        });
      },
      {
        root: null,
        rootMargin: "0px 0px -50% 0px",
        threshold: 0.1,
      },
    );

    sections.forEach((section) => {
      const element = document.getElementById(section.id);
      if (element) observer.observe(element);
    });

    window.addEventListener("scroll", handleScroll);

    return () => {
      window.removeEventListener("scroll", handleScroll);
      sections.forEach((section) => {
        const element = document.getElementById(section.id);
        if (element) observer.unobserve(element);
      });
    };
  }, []);

  return (
    <>
      {showQuickNav && (
        <IntroQuickNav sections={sections} activeSection={activeSection} />
      )}
      <Box
        className={intropageStyles.intro_top_bg}
        sx={{ display: "flex", alignItems: "center" }}
      >
        <Container
          sx={{
            pt: 8,
            pb: 6,
          }}
          maxWidth="lg"
        >
          <Typography
            component="h2"
            variant="h2"
            sx={{ fontWeight: "400" }}
            gutterBottom
          >
            커피물류 플랫폼
          </Typography>
          <Typography
            component="p"
            variant="subtitle1"
            sx={{ mb: 3.5, fontSize: "1.125rem" }}
          >
            부산의 커피 도시를 함께 만들어 가고자합니다.
          </Typography>
        </Container>
      </Box>
      <Box>
        <Box
          id="businessGoals"
          sx={{
            backgroundColor: "bluesky",
          }}
        >
          <Container
            sx={{
              pt: 8,
              pb: 6,
            }}
            maxWidth="lg"
          >
            <Typography
              component="h3"
              variant="h3"
              sx={{ marginBottom: "32px", textAlign: "center" }}
            >
              사업추진 목표
            </Typography>

            <InBox>
              <img src={intro_section01} alt="제조 데이터 시스템 구성 이미지" />
            </InBox>
            <Divider
              sx={{
                my: 8,
                mx: "auto",
                backgroundColor: "#003E8D",
                widht: "90%",
              }}
            />
            <InBox>
              <img
                src={intro_section02_a}
                alt="제조 데이터 시스템 구성 이미지"
              />
            </InBox>
            <Divider
              sx={{
                my: 8,
                mx: "auto",
                backgroundColor: "#003E8D",
                widht: "90%",
              }}
            />
            <InBox>
              <img src={intro_section03} alt="제조 데이터 시스템 구성 이미지" />
            </InBox>
          </Container>
        </Box>
        {/* contentsA E */}
        <Box id="blockchainLogistics">
          <Container
            sx={{
              pt: 8,
              pb: 6,
            }}
            maxWidth="lg"
          >
            <Typography
              component="h3"
              variant="h3"
              sx={{ marginBottom: "32px", textAlign: "center" }}
            >
              블록체인 기반 물류
            </Typography>
            <InBox
              customStyle={{
                display: "flex",
                justifyContent: "left",
                paddingLeft: "10%",
                marginTop: "4%",
              }}
            >
              <img
                src={intro_section02_b}
                alt="제조 데이터 시스템 구성 이미지"
                style={{ width: "85%", paddingLeft: "0" }}
              />
            </InBox>
          </Container>
        </Box>
        {/* contentsB E */}
        <Box id="coffeeAnalysis" sx={{ backgroundColor: "#EFF2F4" }}>
          <Container
            sx={{
              pt: 8,
              pb: 6,
            }}
            maxWidth="lg"
          >
            <Typography
              component="h3"
              variant="h5"
              sx={{ marginBottom: "32px", lineHeight: 2 }}
            >
              커피분석 방법
            </Typography>
            <Grid2 container spacing={2}>
              {intro_fourth_texts.map((item, index) => (
                <Grid2 size={{ xs: 12, sm: 8, md: 4 }} key={index}>
                  {/* <InBox> */}
                  <Box sx={{ textAlign: "center" }}>
                    <img src={item.image} alt={item.imageLabel} />
                    <Typography variant="h5" sx={{ mt: 2 }}>
                      {item.title}
                    </Typography>
                    <Typography variant="body1">{item.description}</Typography>
                  </Box>
                  {/* </InBox> */}
                </Grid2>
              ))}
            </Grid2>
          </Container>
        </Box>
        {/* contentsC E */}
        <Box id="blockchainCoffee" sx={{}}>
          <Container
            sx={{
              pt: 8,
              pb: 6,
            }}
            maxWidth="lg"
          >
            <Typography
              component="h3"
              variant="h5"
              sx={{ marginBottom: "32px", lineHeight: 2 }}
            >
              블록체인과 커피 이해하기
            </Typography>
            <Grid2 container spacing={2}>
              {intro_fifth_texts.map((item, index) => (
                <Grid2 size={{ xs: 12, sm: 8, md: 4 }} key={index}>
                  {/* <InBox> */}
                  <Box sx={{ textAlign: "center" }}>
                    <img src={item.image} alt={item.imageLabel} />
                    <Typography variant="h5" sx={{ mt: 2 }}>
                      {item.title}
                    </Typography>
                    <Typography variant="body1">{item.description}</Typography>
                  </Box>
                  {/* </InBox> */}
                </Grid2>
              ))}
            </Grid2>
          </Container>
        </Box>
        {/* contentsD E */}
      </Box>
    </>
  );
};
export default IntroPage;
