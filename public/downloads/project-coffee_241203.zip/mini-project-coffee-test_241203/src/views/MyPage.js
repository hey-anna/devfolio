import React, { useState, useEffect, useMemo } from "react";
import dayjs from "dayjs";
import {
  Box,
  Container,
  Grid2,
  Typography,
  Stack,
  Chip,
  Button,
} from "@mui/material";
import { useSearchQuery } from "../hooks/useSearch/useSearchQuery";
import { useOriginInfoQuery } from "../hooks/useMypage/useOriginInfoQuery";
import { useCountryOriginQuery } from "../hooks/useCommon/useCountryOriginQuery";

import { MyPageProductSearchForm } from "../layouts/mypage/MyPageProductSearchForm";
import { MyPageProductDataArea } from "../layouts/mypage/MyPageProductDataArea";
import { processingTypes } from "../constants/searchpageTexts";

const MyPage = () => {
  const [formData, setFormData] = useState({
    CoffeeName: "", // 생두 이름
    BeanVariety: "", // 생두 품종
    ProductionCountryCode: "", // 원산지 코드
    ProductionYear: "", // 생산년도
    Farm: "", // 생산농장
    Altitude: "", // 고도
    ProcessingCode: "", // 가공방식
    StockDate: "", // 입고일자
  });
  const [searchPayload, setSearchPayload] = useState({});
  const [searchTriggered, setSearchTriggered] = useState(false);
  const [selectedOriginValue, setSelectedOriginValue] = useState({
    code: "",
    name: "",
  });

  console.log("##@@@selectedOriginValue", selectedOriginValue);

  const handleOriginSelect = (originData) => {
    console.log("##@@Received origin data:", originData);
    setSelectedOriginValue({
      code: originData.originCode,
      name: originData.originName,
    });
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    console.log(`Input changed - ${name}: ${value}`);
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleDateChange = (newValue) => {
    const date = dayjs(newValue);
    if (date.isValid()) {
      const formattedDate = date.format("YYYYMMDD");
      setFormData((prevFormData) => ({
        ...prevFormData,
        StockDate: formattedDate,
      }));
    } else {
      console.error("Invalid date provided");
    }
  };

  const handleYearChange = (newValue) => {
    const yearDate = newValue ? dayjs(newValue).startOf("year") : null;
    if (yearDate && yearDate.isValid()) {
      const yearAsNumber = yearDate.year();
      console.log("####Selected Year:", yearAsNumber);
      setFormData((prevFormData) => ({
        ...prevFormData,
        ProductionYear: yearAsNumber,
      }));
    } else {
      console.error("Invalid date provided");
      setFormData((prevFormData) => ({
        ...prevFormData,
        ProductionYear: null,
      }));
    }
  };

  const handleReset = () => {
    setFormData({
      CoffeeName: "",
      BeanVariety: "",
      ProductionCountryCode: "",
      ProductionYear: null,
      Farm: "",
      Altitude: "",
      ProcessingCode: "",
      StockDate: null,
    });
  };

  const handleSearch = () => {
    const formattedStockDate = dayjs(formData.StockDate).format("YYYYMMDD");
    const processingCodeKey = Object.keys(processingTypes).find(
      (key) => processingTypes[key] === formData.ProcessingCode,
    );
    const filteredPayload = Object.entries(formData).reduce(
      (acc, [key, value]) => {
        if (value) {
          if (key === "ProcessingCode") {
            acc[key] = processingCodeKey || value;
          } else if (key === "StockDate") {
            acc[key] = formattedStockDate;
          } else {
            acc[key] = value;
          }
        }
        return acc;
      },
      {},
    );

    filteredPayload.ProductionCountryCode = selectedOriginValue.code;
    console.log("Selected Origin Code:", selectedOriginValue.code);
    setSearchPayload(filteredPayload);
    setSearchTriggered(true);
  };

  const {
    data: greenBeansData,
    isLoading,
    error,
  } = useSearchQuery(
    {
      keyword: searchPayload,
      pageType: "myPage",
    },
    {
      enabled: searchTriggered,
    },
  );

  return (
    <Container sx={{ pt: 8, pb: 6 }}>
      <Typography
        component="h2"
        variant="h5"
        sx={{
          fontWeight: "400",
          lineHeight: "1.5",
        }}
        gutterBottom
      >
        My생두 검색하기
      </Typography>
      <MyPageProductSearchForm
        formData={formData}
        selectedOrigin={selectedOriginValue}
        onFinalClickInfoChange={handleOriginSelect}
        onInputChange={handleInputChange}
        onDateChange={handleDateChange}
        onYearChange={handleYearChange}
        onSearch={handleSearch}
        processingTypes={processingTypes}
        greenBeansData={greenBeansData}
        onReset={handleReset}
        searchResultsCount={
          searchTriggered && greenBeansData?.length
            ? greenBeansData.length
            : "0"
        }
      />

      {searchTriggered && greenBeansData && (
        <MyPageProductDataArea
          greenBeansData={greenBeansData}
          formData={formData}
        />
      )}
    </Container>
  );
};

export default MyPage;
