import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Container, Grid2, Box, Alert } from "@mui/material";
import { ProductDetailTopArea } from "../../layouts/searchpage/productDetailpage/ProductDetailTopArea";
import { useSearchDetailQuery } from "../../hooks/useSearch/useSearchDetailQuery";
import { processingTypes } from "../../constants/searchpageTexts";
import { ProductDetailGraphArea } from "../../layouts/searchpage/productDetailpage/ProductDetailGraphArea";

export const ProductDetailPage = () => {
  const { coffee_key_id } = useParams();

  const {
    data: details,
    isLoading,
    isError,
    error,
  } = useSearchDetailQuery(coffee_key_id);

  console.log("##details", details);

  // 대체 이미지 URL
  const fallbackImageUrl =
    "https://media.istockphoto.com/id/2164909312/ko/%EC%82%AC%EC%A7%84/%EC%BB%A4%ED%94%BC-%EC%9B%90%EB%91%90-%EB%A1%9C%EC%8A%A4%ED%8C%85-%EC%A0%9C%ED%92%88-%EC%88%98%EC%B6%9C-%EB%98%90%EB%8A%94-%ED%92%88%EC%A7%88-%EB%B3%B4%EC%A6%9D%EC%9D%84-%EC%9C%84%ED%95%9C-%EC%84%B1%EB%B6%84%EC%9D%B4-%EC%9E%88%EB%8A%94-%EA%B8%B0%EA%B3%84-%EB%B0%8F-%EA%B3%B5%EC%9E%A5-%EB%B9%84%EC%96%B4-%EC%9E%88%EB%8A%94-%ED%8F%89%EB%A9%B4%EB%8F%84-%EB%B0%8F-%ED%94%84%EB%A6%AC%EB%AF%B8%EC%97%84-%EC%97%90%EC%8A%A4%ED%94%84%EB%A0%88%EC%86%8C-%EC%B9%B4%ED%8E%98%EC%9D%B8-%EB%98%90%EB%8A%94-%EC%8B%A0%EC%84%A0%ED%95%9C-%EB%B8%94%EB%A0%8C%EB%93%9C%EB%A5%BC-%EC%9C%84%ED%95%9C-%EC%9E%A5%EB%B9%84%EB%A1%9C-%EC%A0%9C%EC%A1%B0.jpg?s=1024x1024&w=is&k=20&c=U4mS4xAItRN1ml8zvDRJ1becEN0UEoA0KbnVLqENKdA=";

  console.log("##details?.AnalysisInfo", details?.AnalysisInfo);
  return (
    <>
      <Box sx={{ pb: 6, mt: 12 }}>
        <Container maxWidth="lg">
          {details && (
            <ProductDetailTopArea
              dataImageUrl={details?.ImageUrl || fallbackImageUrl}
              dataTitle={details.CoffeeName}
              dataBeanVariety={details.BeanVariety.split(", ")}
              dataProductionCountry={details.CountryNameEng}
              dataCompanyName={details.Company}
              dataFarmName={details.Farm}
              dataProductionYear={details.ProductionYear}
              dataProcessingMethod={processingTypes[details.ProcessingCode]}
            />
          )}
          {details?.AnalysisInfo && details?.AvgAnalysisInfo ? (
            <ProductDetailGraphArea
              dataAnalysisInfo={details.AnalysisInfo}
              dataAvgAnalysisInfo={details.AvgAnalysisInfo}
            />
          ) : (
            <Box sx={{ textAlign: "center", mt: 6 }}>
              <Alert severity="info">그래프 데이터를 찾을 수 없습니다.</Alert>
            </Box>
          )}
        </Container>
      </Box>
    </>
  );
};
