import React from "react";
import { useNavigate } from "react-router-dom";
import {
  Box,
  Container,
  Grid2,
  Typography,
  Stack,
  Chip,
  Button,
} from "@mui/material";
import { ProcessImageCard } from "../layouts/homepage/ProcessImageCard";
import { CountCard } from "../layouts/homepage/CountCard";
import { PopularAndNewSection } from "../layouts/homepage/PopularAndNewSection";
import homepageStyles from "../assets/styles/views/homepage.module.css";
import main_top_coffee_cup from "../assets/images/homeImages/main_top_coffee_cup.svg";
import { SouthEast } from "@mui/icons-material";

const HomePage = () => {
  const navigate = useNavigate();
  return (
    <>
      <Box>
        {/* 첫번째 영역 S */}
        <Box>
          <Container sx={{ pt: 8, pb: 6 }}>
            <Grid2 container spacing={5}>
              <Grid2 item size={6.5} sx={{ mb: 12 }}>
                <Box
                  sx={{
                    maxHeight: "322px",
                  }}
                >
                  <Typography
                    component="h2"
                    variant="h2"
                    sx={{
                      fontWeight: "400",
                      lineHeight: "1.5",
                      fontSize: "3rem",
                    }}
                    gutterBottom
                  >
                    커피의 향을 데이터화 하다
                    <Typography
                      component="span"
                      variant="h2"
                      sx={{
                        display: "flex",
                        fontWeight: "400",
                        lineHeight: "1.5",
                        pl: "8%",
                        fontSize: "3rem",
                      }}
                    >
                      커피의 맛을 데이터화 하다
                    </Typography>
                    <Typography
                      component="span"
                      variant="h2"
                      sx={{
                        display: "flex",
                        fontWeight: "400",
                        lineHeight: "1.5",
                        pl: "16%",
                        fontSize: "3rem",
                      }}
                    >
                      커피의 생을 데이터화 하다
                    </Typography>
                  </Typography>
                  <Typography
                    component="p"
                    variant="subtitle1"
                    sx={{ mb: 3.5, fontSize: "1.125rem" }}
                  >
                    2023년 연구특구진흥재단에서 추진한 기술사업화 협업플랫폼
                    구축사업에 선정된
                    <br /> 부산테크노파크가 플랫폼 사업의 일환으로 블록체인을
                    통한
                    <br />
                    커피 물류 플랫폼 사업을 수행하였습니다. BoB(Best of Busan)는
                    해당 서비스의 브랜드 명입니다.
                  </Typography>
                </Box>
              </Grid2>
              {/* 텍스트 영역 */}
              <Grid2
                item
                size={3.5}
                className={homepageStyles.main_top_coffee_cup_image_grid}
              >
                <Box
                  className={homepageStyles.main_top_coffee_cup_image_container}
                >
                  <img src={main_top_coffee_cup} alt="main_top_coffee_cup" />
                </Box>
              </Grid2>
              {/* 이미지 영역 */}
            </Grid2>
            {/* Top 영역 */}
            <Box className={homepageStyles.main_top_quik_button}>
              <Button
                variant="contained"
                size="large"
                sx={{
                  background: "#301D06",
                  height: "8",
                  fontsize: "1.125rem",
                  pt: 3,
                  pb: 3,
                  pl: 5,
                  pr: 5,
                  borderRadius: 4,
                  borderTopLeftRadius: 0,
                  borderBottomRightRadius: 0,
                }}
                endIcon={<SouthEast />}
                onClick={() => navigate("/mypage")}
              >
                원두 커피 등록하러 가기
              </Button>
            </Box>
            {/* Button 영역 */}
          </Container>
        </Box>
        {/* 첫번째 영역 E */}
        {/* 두번째 영역 S */}
        <Box>
          <Container sx={{ pt: 8, pb: 6 }}>
            <ProcessImageCard />
          </Container>
        </Box>

        {/* 두번째 영역 E */}
        {/* 세번째 영역 S */}
        <Box sx={{ background: "#FAF4EE" }}>
          <Container sx={{ pt: 8, pb: 6 }}>
            <CountCard />
          </Container>
        </Box>
        {/* 세번째 영역 E */}
        {/* 네번째 영역 S */}
        <Box sx={{}}>
          <Container sx={{ pt: 8, pb: 6 }}>
            <PopularAndNewSection />
          </Container>
        </Box>
        {/* 네번째 영역 E */}
      </Box>
    </>
  );
};

export default HomePage;
