import * as React from "react";
import { Navigate, useLocation } from "react-router-dom";

const withAuthRoutes = [
  // "/mypage",
  // "/mypage/디테일",
];
const withoutAuthRoutes = [
  "/",
  "/intro",
  "/search",
  "/detail/:coffee_key_id",
  "/statistics",
  "/login",
];

console.log("##### Navigate", Navigate);
export default function AuthGuard({ children }) {
  const access = sessionStorage.getItem("access");
  const refresh = sessionStorage.getItem("refresh");
  const isLoggedIn = access && refresh;
  const { pathname } = useLocation();

  console.log("##### isLoggedIn:", isLoggedIn);
  console.log("##### pathname:", pathname);

  if (withAuthRoutes.includes(pathname) && !isLoggedIn) {
    return <Navigate to="/login" replace />;
  }

  return children;
}
