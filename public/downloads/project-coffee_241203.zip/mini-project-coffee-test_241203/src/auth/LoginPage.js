import React, { useEffect, useState, useContext } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import QRCode from "react-qr-code";
import client from "../api/commonApi";
import { Button, Stack, Box, Typography, Container } from "@mui/material";
import { v4 } from "uuid";

const decodeJWT = (token) => {
  try {
    const base64Url = token.split(".")[1];
    const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
    const jsonPayload = decodeURIComponent(
      atob(base64)
        .split("")
        .map((c) => "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2))
        .join(""),
    );
    return JSON.parse(jsonPayload);
  } catch (error) {
    console.error("Invalid token:", error);
    return null;
  }
};

const LoginPage = () => {
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const [code, setCode] = useState({});
  const [limit, setLimit] = useState(180);

  useEffect(() => {
    console.log("pathname", pathname);

    // 임시 Access Token을 sessionStorage에 설정
    sessionStorage.setItem(
      "access",
      "eyJ0eXAiOiAiSldUIiwgImFsZyI6ICJFZERTQSIsICJraWQiOiAiZGlkOnNvdjpQNXo0d3NHY0IzTkFDak5HUTZLUTdYI2tleS0xIn0.eyJfc2QiOiBbInZEUGU1Y19HVzNpeGtPQndGZkcxQ2dqVzhra2x3SXpMSmprcUtlN1h4MGMiXSwgImlzcyI6ICJodHRwczovL3Utc3RjLm5ldCIsICJpYXQiOiAxNzMxODk0OTYxLCAiZXhwIjogMTczMTk4MTM2MSwgIm1lbWJlcklkIjogIjI1NDk0OGNhLTFkMDgtNDk4Ni1hODNhLWVmMTA5ZDRhYjcxMyIsICJtZW1iZXJOYW1lIjogImxvZ2luX3Rlc3RfMjAiLCAibWVtYmVyVHlwZSI6IG51bGwsICJjb21wYW55TmFtZSI6ICJcdWQ1MGNcdWI3YWJcdWQzZmMiLCAiX3NkX2FsZyI6ICJzaGEtMjU2In0.D0Sc6AGgov9VcoVqBuAZPw48WR-fAoeHq0_Ot_trW1NmURWWVP3_DkIfmq62kFjBlLwNXJ5gVmg3Ia5tNSbPBg~WyJOcnBaOEVjZHhzb0xpakhETkNaMWdnIiwgImRpZCIsICJkaWQ6c292OlVFTE5tRVF2dTNwR3J1RVRXOHJEaFMiXQ~",
    );

    // Access Token 디코드 및 출력 (테스트 목적)
    const accessToken = sessionStorage.getItem("access");
    const decodedPayload = decodeJWT(accessToken);
    console.log("Decoded JWT Payload:", decodedPayload);
  }, [pathname]);
  //

  useEffect(() => {
    if (limit === 0) {
      // navigate("/");
      navigate(0);

      return;
    }
  }, [limit, navigate]);

  useEffect(() => {
    const pulling_key = v4().toString();
    const c = {
      // type: "login",
      type: "user/login",
      data: {
        pulling_key: pulling_key,
        subscription_id: "",
      },
    };

    setCode(c);

    const limitInterval = setInterval(() => {
      setLimit((time) => time - 1);
    }, 1000);

    const interval = setInterval(() => {
      // let location = useLocation();
      const accessToken = sessionStorage.getItem("access");

      console.log("pathname", pathname);
      // location.pathname: 현재 페이지의 경로 URL

      client
        .create({ timeout: 3000 })
        .get("/member/login", {
          headers: {
            pulling_key: pulling_key,
            Authorization: `Bearer ${accessToken}`, // Access Token을 Authorization 헤더에 추가
            // access,
            // refresh,
          },
        })
        .then((response) => {
          clearInterval(interval);

          sessionStorage.setItem(
            "connection_id",
            response.headers.connection_id,
          );
          console.log("## connection_id:", response.headers.connection_id);
          console.log("## JWT access:", accessToken);

          // JWT 페이로드 디코드 후 콘솔 출력
          const decodedPayload = decodeJWT(response.headers.access);

          console.log("Decoded JWT Payload:", decodedPayload);
          console.log("## JWT access:", decodedPayload.access);
          console.log("## JWT Name:", decodedPayload.connection_id);
          // 메인화면으로 이동하기
          if (pathname === "/login") {
            navigate("/");
          } else {
            window.location.reload();
          }
        })
        .catch((reason) => {
          console.log(reason);
        });
    }, 3000);

    return () => {
      clearInterval(limitInterval);
      clearInterval(interval);
    };
  }, []);

  return (
    <>
      <Box
        sx={{
          pb: 6,
          m: 0,
          p: 0,

          height: "100%",
          display: "flex",
          alignItems: "center",
        }}
      >
        <Container
          sx={{
            p: 0,
          }}
          maxWidth="lg"
        >
          <Box>
            <Typography
              component="h2"
              variant="h5"
              sx={{ fontWeight: "400", textAlign: "center" }}
              gutterBottom
            >
              커피 물류 플랫폼
              <Typography component="h2" variant="h4" sx={{ mt: 1 }}>
                로그인
              </Typography>
            </Typography>
          </Box>
          <Box
            sx={{
              width: "100%",
              display: "flex",
              justifyContent: "center",
              margin: "20px 0 10%",
            }}
          >
            <div
              style={{
                height: "auto",
                margin: "0 auto",
                maxWidth: 104,
                width: "100%",
              }}
            >
              <QRCode
                size={256}
                style={{ height: "auto", maxWidth: "100%", width: "100%" }}
                value={JSON.stringify(code)}
                viewBox={`0 0 256 256`}
              />
            </div>
          </Box>
          인증시간 : {`${limit} 초`}
        </Container>
      </Box>
    </>
  );
};
export default LoginPage;
