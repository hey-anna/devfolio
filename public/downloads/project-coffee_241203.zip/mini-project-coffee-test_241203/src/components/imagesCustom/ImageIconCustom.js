// chip에 사용하려고 하였으나, 사용이 안됨 일단 다른곳에 필요하면 사용하는데, 사용하지 않는 경우 삭제 하기
// import React from "react";

// // 이미지 아이콘 컴포넌트 정의
// const ImageIconCustom = ({ src, alt, width = 24, height = 24 }) => {
//   console.log("Image src:", src); // 콘솔에 경로 출력
//   return <img src={src} alt={alt} style={{ width, height }} />;
// };

// export default ImageIconCustom;
