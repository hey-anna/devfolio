import React from "react";
import { YearSelector } from "../dates/YearSelector";
import dayjs from "dayjs";

const BeanDateSelector = ({ value, onChange, placeholder }) => {
  return (
    <YearSelector
      views={["year", "month", "day"]}
      openTo="year"
      minDate={dayjs("2000-01-01")}
      maxDate={dayjs("2030-12-31")}
      defaultValue={null}
      name="StockDate"
      value={value ? dayjs(value) : null}
      onChange={onChange}
      placeholder="입고일자 선택"
    />
  );
};

export default BeanDateSelector;
