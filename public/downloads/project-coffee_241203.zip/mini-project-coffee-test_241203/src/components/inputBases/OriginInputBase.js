import React from "react";
import { styled } from "@mui/material/styles";
import { Button, Toolbar } from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";

const SearchBtn = styled(Button)({
  width: "100%",
  boxShadow: "none",
  textTransform: "none",
  fontSize: "1.125rem",
  minHeight: "unset",
  backgroundColor: "#ebebebb3",
  borderColor: "#b7b6b6b3",
  justifyContent: "space-between",
  color: "#999",
  "&:hover": {
    backgroundColor: "rgb(235,235,235,0.9)",
    boxShadow: "none",
  },
});

const IconSx = {
  color: "#999",
  root: {},
};

const OriginInputBase = ({ selectedOrigin, onClick, value }) => {
  return (
    <SearchBtn
      name="ProductionCountryCode"
      value={value}
      onClick={onClick}
      variant="outlined"
      endIcon={
        <SearchIcon
          sx={{
            color: "#999",
          }}
        />
      }
      sx={IconSx}
    >
      {selectedOrigin.name || "원산지 선택"}
    </SearchBtn>
  );
};

export default OriginInputBase;
