import React from "react";
import { YearSelector } from "../dates/YearSelector";
import dayjs from "dayjs";

const BeanYearSelector = ({ value, onChange, placeholder }) => {
  return (
    <YearSelector
      views={["year"]}
      openTo="year"
      minDate={dayjs("2000-01-01")}
      maxDate={dayjs("2030-12-31")}
      value={value ? dayjs(value) : null}
      onChange={onChange}
      placeholder="생산년도 선택"
    />
  );
};

export default BeanYearSelector;
