import React from "react";
import { styled, alpha } from "@mui/material/styles";
import { Toolbar, InputBase } from "@mui/material";

const SearchBgColor = styled("div")(({ theme }) => ({
  width: "100%",
  position: "relative",
  borderRadius: theme.shape.borderRadius,
  backgroundColor: alpha(theme.palette.common.white, 0.15),
  "&:hover": {
    backgroundColor: alpha(theme.palette.common.white, 0.25),
  },
  "&:focus": {
    backgroundColor: alpha(theme.palette.common.white, 0.25),
  },
  marginLeft: 0,
  width: "100%",
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  width: "100%",
  "& .MuiInputBase-input": {
    fontSize: "1.125rem",
    padding: theme.spacing(1, 1, 1, 0),
    paddingLeft: `calc(1em + ${theme.spacing(-0.5)})`,
    paddingRight: `calc(1em + ${theme.spacing(0.5)})`,
    transition: theme.transitions.create("width"),
    mt: 4,
  },
}));

export const BeanInputBase = ({
  type,
  id,
  placeholder,
  inputProps,
  value,
  onChange,
  onKeyDown,
  name,
}) => (
  <SearchBgColor>
    <StyledInputBase
      type={type}
      id={id}
      name={name}
      placeholder={placeholder}
      inputProps={inputProps}
      value={value}
      onChange={onChange}
      onKeyDown={onKeyDown}
    />
  </SearchBgColor>
);
