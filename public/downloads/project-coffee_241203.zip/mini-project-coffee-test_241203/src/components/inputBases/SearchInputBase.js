import React from "react";
import { styled, alpha } from "@mui/material/styles";
import { InputBase } from "@mui/material";

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  width: "100%",
  "& .MuiInputBase-input": {
    fontSize: "1.125rem",
    padding: theme.spacing(1, 1, 1, 0),
    paddingLeft: `calc(1em + ${theme.spacing(-0.5)})`,
    paddingRight: `calc(1em + ${theme.spacing(0.5)})`,
    transition: theme.transitions.create("width"),
    mt: 4,
  },
}));

export const SearchInputBase = ({
  type,
  id,
  placeholder,
  inputProps,
  value,
  onChange,
  onKeyDown,
  name,
}) => (
  <StyledInputBase
    type={type}
    id={id}
    name={name}
    placeholder={placeholder}
    inputProps={inputProps}
    value={value}
    onChange={onChange}
    onKeyDown={onKeyDown}
  />
);
