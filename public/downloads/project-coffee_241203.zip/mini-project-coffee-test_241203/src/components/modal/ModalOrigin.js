import React, { useEffect, useRef, useState, useContext } from "react";
import { styled } from "@mui/material/styles";
import { OriginSearchBar } from "../searchs/OriginSearchBar";
import dayjs from "dayjs";
import {
  Container,
  Box,
  IconButton,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
} from "@mui/material";
import ModalOriginDataGrid from "../dataGrid/ModalOriginDataGrid";
import { useCountryOriginQuery } from "../../hooks/useCommon/useCountryOriginQuery";
import { Close } from "@mui/icons-material";

const ModalOrigin = ({ isOpen, handleClose, onFinalClickInfoChange }) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [searchOriginTriggered, setSearchOriginTriggered] = useState(false);
  const { data: originInfo, isSuccess } = useCountryOriginQuery(
    searchTerm,
    searchOriginTriggered,
  );

  const handleOnCellClick = (params) => {
    const originInputName = params.row.CountryNameEng;
    const requestCountryCode = params.row.ProductionCountryCode;

    onFinalClickInfoChange({
      originName: originInputName,
      originCode: requestCountryCode,
    });
    handleClose();
  };

  const handleSearch = (newSearchTerm) => {
    console.log("## Search Parameters:", originInfo);
    setSearchTerm(newSearchTerm);
    setSearchOriginTriggered(true);
  };

  const datagridSx = {
    border: "0",
    "& .MuiDataGrid-root": {
      border: "0px !important",
    },
    "& .MuiDataGrid-main": {},
    "& .MuiDataGrid-root--densityStandard": {},
    "& .MuiDataGrid-withBorderColor": {
      border: 0,
    },
    '& div[data-rowIndex][role="row"]:nth-of-type(5n-4)': {
      "& div": {},
    },
    "& .MuiDataGrid-virtualScrollerRenderZone": {
      "& .MuiDataGrid-row": {
        "&:nth-of-type(2n)": { backgroundColor: "rgba(238, 242, 245, 1)" },
      },
    },
    "& .MuiDataGrid-cell:hover:nth-of-type(7)": {
      cursor: "pointer !important",
      color: "red",
    },
    "& .MuiDataGrid-cell:nth-of-type(7)": {
      "& .MuiDataGrid-cellContent": {
        borderBottom: "1px solid #000",
      },
    },
    "& .disabled-cell": {
      pointerEvents: "none",
      color: "rgba(0, 0, 0, 0.26)",
      "& .MuiDataGrid-cellContent": {
        borderBottom: "0 !important",
      },
    },
    "&.MuiDataGrid-root .MuiDataGrid-cell:focus-within": {
      outline: "none !important",
    },
    "& .MuiDataGrid-columnHeaders": {
      fontSize: 14,
      minHeight: "55px !important",
      maxHeight: "55px !important",
      lineHeight: "55px !important",
      borderTop: "#29314A 3px solid",
      borderBottom: "#29314A 3px solid",
      borderRadius: "0px !important",
    },
    "& .MuiDataGrid-footerContainer": {
      fontSize: 14,
      minHeight: "40px !important",
      maxHeight: "40px !important",
      lineHeight: "40px !important",
    },
  };
  return (
    <>
      <Box sx={{ flexGrow: 1, overflow: "hidden", px: 3 }}>
        <Dialog open={isOpen} onClose={handleClose} fullWidth maxWidth="sm">
          <DialogTitle
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            원산지 선택
            <IconButton
              aria-label="close"
              onClick={handleClose}
              sx={{
                position: "absolute",
                right: 8,
                top: 8,
                color: (theme) => theme.palette.grey[500],
              }}
            >
              <Close />
            </IconButton>
          </DialogTitle>
          {/* 타이틀 */}
          <DialogContent dividers>
            <Container
              sx={{
                pt: 3,
                pb: 2,
              }}
            >
              <Box
                sx={{
                  width: "100%",
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  flexDirection: "column",
                }}
              >
                <OriginSearchBar value={searchTerm} onSearch={handleSearch} />
                {isSuccess && (
                  <ModalOriginDataGrid
                    originInfoData={originInfo}
                    rows={useCountryOriginQuery}
                    handleOnCellClick={handleOnCellClick}
                    autoCloseText="* 원산지 선택 시 자동으로 창이 닫힘니다."
                    sx={datagridSx}
                  />
                )}
                {/* data Area E */}
              </Box>
            </Container>
          </DialogContent>
          {/* 콘텐츠 */}
          <DialogActions></DialogActions>
        </Dialog>
      </Box>
    </>
  );
};

export default ModalOrigin;
