import { useState } from "react";
import { styled, alpha } from "@mui/material/styles";
import SearchIcon from "@mui/icons-material/Search";
import RefreshRoundedIcon from "@mui/icons-material/RefreshRounded";
import { Button, Box, Toolbar, InputBase } from "@mui/material";
import { Place } from "@mui/icons-material";

const Search = styled("div")(({ theme }) => ({
  position: "relative",
  borderRadius: theme.shape.borderRadius,
  backgroundColor: alpha(theme.palette.common.white, 0.15),
  "&:hover": {
    backgroundColor: alpha(theme.palette.common.white, 0.25),
  },
  "&:focus": {
    backgroundColor: alpha(theme.palette.common.white, 0.25),
  },
  marginRight: theme.spacing(1),
  marginLeft: 0,
  width: "100%",
  [theme.breakpoints.up("sm")]: {
    marginLeft: theme.spacing(3),
    width: "auto",
  },
}));

const SearchIconWrapper = styled("div")(({ theme }) => ({
  padding: theme.spacing(0, 2),
  height: "100%",
  position: "absolute",
  pointerEvents: "none",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  zIndex: "1",
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  width: "100%",
  "& .MuiInputBase-input": {
    fontSize: "1.125rem",
    padding: theme.spacing(1, 1, 1, 0),
    paddingLeft: `calc(1em + ${theme.spacing(4)})`,
    paddingRight: `calc(1em + ${theme.spacing(0.5)})`,
    transition: theme.transitions.create("width"),
    width: "100%",
  },
}));

const ToolbarSx = styled(Toolbar)(({ theme }) => ({
  minHeight: "unset !important",
  marginBottom: 8,
  marginLeft: 0,
  padding: "0px !important",
  "& .MuiInputBase-root :focus": {
    background: "#fff",
    marginLeft: 0,
  },
  boxShadow: "none",
  "& > div": {
    background: "#ebebebb3",
    marginLeft: "0",
    border: "1px solid #b7b6b6b3",
    borderRadius: "4px",
  },
  "& > div:focus": {},
  "& > div:hover": {
    border: "1px solid #29304a ",
  },

  "& .MuiInputBase-input": {},
  "& .MuiInputBase-input:focus": {
    border: "1px solid #29304a ",
  },
}));

export const OriginSearchBar = ({ onSearch }) => {
  const [originName, setOriginName] = useState("");
  console.log("## originName", originName);
  const handleOriginNameChange = (e) => {
    console.log("## originName", originName);
    const value = e.target.value;
    setOriginName(value);
  };

  const handleReset = () => {
    setOriginName("");
  };

  function searchButton(e) {
    e.preventDefault();
    onSearch(originName);
    console.log("검색 조건 :", originName);
  }

  function handleKeyPress(e) {
    if (e.code === "Enter") {
      e.preventDefault();
      console.log("Enter key pressed");
      onSearch(originName);
    }
  }

  return (
    <Box sx={{ width: 1, mb: 2 }}>
      <ToolbarSx>
        <Search sx={{ flexGrow: 1 }}>
          <SearchIconWrapper>
            <Place
              onClick={searchButton}
              sx={{
                color: "#00000063",
              }}
            />
          </SearchIconWrapper>
          <StyledInputBase
            type="search"
            id="search"
            placeholder="원산지를 영문으로 입력해주세요"
            inputProps={{ "aria-label": "검색하기" }}
            value={originName}
            onChange={handleOriginNameChange}
            onKeyDown={handleKeyPress}
          />
        </Search>
        <Button
          onClick={searchButton}
          variant="contained"
          sx={{
            height: "43.88px",
            boxShadow: "none",
            backgroundColor: "#333",
          }}
          startIcon={<SearchIcon sx={{ color: "#fff" }} />}
        >
          검색
        </Button>
      </ToolbarSx>
      <Button
        onClick={handleReset}
        variant="contained"
        sx={{
          pt: 1,
          pb: 2,
          boxShadow: "none",
          color: "#000000de",
          backgroundColor: "#fff",
        }}
        startIcon={<RefreshRoundedIcon sx={{ color: "#000000de" }} />}
      >
        초기화
      </Button>
    </Box>
  );
};
