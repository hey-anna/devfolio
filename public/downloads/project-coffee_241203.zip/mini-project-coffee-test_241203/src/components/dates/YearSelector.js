import React from "react";
import { styled, alpha } from "@mui/material/styles";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import dayjs from "dayjs";
import { TextField, InputBase } from "@mui/material";

const StyledYearInputBase = styled(InputBase)(({ theme }) => ({
  "& .MuiInputBase-input": {
    fontSize: "1.125rem",
    padding: theme.spacing(1, 1, 1, 0),
    paddingLeft: `calc(1em + ${theme.spacing(-0.5)})`,
    paddingRight: `calc(1em + ${theme.spacing(0.5)})`,
  },
}));

export const YearSelector = ({
  value,
  onChange,
  views,
  openTo,
  minDate,
  maxDate,
  defaultValue,
  sx,
  placeholder,
}) => {
  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <DatePicker
        value={value}
        onChange={onChange}
        views={views}
        openTo={openTo}
        minDate={minDate}
        maxDate={maxDate}
        defaultValue={defaultValue}
        sx={sx}
        slots={{
          textField: TextField,
        }}
        slotProps={{
          textField: {
            placeholder: placeholder,
            fullWidth: true,
          },
        }}
      />
    </LocalizationProvider>
  );
};
