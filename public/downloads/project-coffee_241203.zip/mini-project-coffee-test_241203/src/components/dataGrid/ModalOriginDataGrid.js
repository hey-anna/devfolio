import React, { useEffect, useState } from "react";
import { DataGrid } from "@mui/x-data-grid";
import { ThemeProvider, createTheme } from "@mui/material/styles";
import { Box, Paper, Typography, Grid2, Stack, Tooltip } from "@mui/material";
import { useCountryOriginQuery } from "../../hooks/useCommon/useCountryOriginQuery";
import BasicTooltip from "../tooltips/BasicTooltip";
const theme = createTheme({
  components: {
    MuiDataGrid: {
      styleOverrides: {
        row: {
          "&.selected-row": {
            backgroundColor: "lightblue",
          },
        },
      },
    },
  },
});

const ModalOriginDataGrid = ({
  handleOnCellClick,
  autoCloseText,
  selectedUserId,
  originInfoData,
  sx,
}) => {
  const formattedData = originInfoData?.map((OriginInfo, index) => ({
    id: index + 1,
    CountryNameKor: OriginInfo.CountryNameKor,
    ProductionCountryCode: OriginInfo.ProductionCountryCode,
    CountryNameEng: OriginInfo.CountryNameEng,
  }));
  const columns = [
    {
      field: "id",
      headerName: "No.",
      flex: 0.5,
    },
    {
      field: "CountryNameKor",
      headerName: "코드값 명칭",
      flex: 3,
      renderCell: (params) => (
        <BasicTooltip title={params.row.CountryNameKor} placement="right-end" />
      ),
      valueGetter: ({ value }) => value || "-",
    },
    {
      field: "ProductionCountryCode",
      headerName: "코드값",
      flex: 3,
      renderCell: (params) => (
        <BasicTooltip
          title={params.row.ProductionCountryCode}
          placement="right-end"
        />
      ),
      valueGetter: ({ value }) => value || "-",
    },

    {
      field: "CountryNameEng",
      headerName: "국가명_영문",
      flex: 3,
      renderCell: (params) => (
        <BasicTooltip title={params.row.CountryNameEng} placement="right-end" />
      ),
      valueGetter: ({ value }) => value || "-",
    },
  ];

  return (
    <ThemeProvider theme={theme}>
      <Grid2
        item
        xs={12}
        sx={{
          width: "100%",
        }}
      >
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            borderRadius: "4px",
            height: 360,
          }}
        >
          <Typography
            component="h3"
            sx={{
              fontWeight: "400",
              color: "#939393",
            }}
          ></Typography>
          <Typography
            component="h3"
            sx={{
              fontWeight: "400",
            }}
            fontSize="14px"
            color="red"
          >
            {autoCloseText}
          </Typography>
          <DataGrid
            sx={sx}
            rows={formattedData || []}
            columns={columns}
            columnHeight={25}
            rowHeight={25}
            onCellClick={handleOnCellClick}
            getRowClassName={(params) =>
              params.id === selectedUserId ? "selected-row" : ""
            }
          />
        </Box>
      </Grid2>
    </ThemeProvider>
  );
};

export default ModalOriginDataGrid;
