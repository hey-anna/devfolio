import * as React from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useState } from "react";
import { DataGrid } from "@mui/x-data-grid";
import { Stack } from "@mui/material";

const ProductDataGrid = ({
  children,
  rows,
  columns,
  onCellClick,
  sx,
  checkboxSelection,
  isDataLoading,
}) => {
  const navigate = useNavigate();

  const getHeightSX = () => {
    return {
      minHeight: 180,
      maxHeight: 700,
      ...sx,
    };
  };
  const handleDetailClick = (params) => {
    const coffeeKeyId = params.row.CoffeeKey;
    navigate(`/detail/${coffeeKeyId}`);
  };
  return (
    <Stack sx={getHeightSX}>
      <DataGrid
        autoHeight
        children={children}
        sx={sx}
        rows={rows}
        columns={columns}
        initialState={{
          pagination: {
            paginationModel: { page: 0, pageSize: 5 },
          },
        }}
        pageSizeOptions={[5, 10]}
        hideFooterSelectedRowCount={true}
        rowHeight={55}
        onCellClick={handleDetailClick}
      />
    </Stack>
  );
};

export default ProductDataGrid;
