import axios from "axios";

const client = axios.create({
  // baseURL: "https://u-stc.net:8821",
  // baseURL: "http://10.10.10.26:9002", // 개발
  baseURL: "https://d478-58-239-32-98.ngrok-free.app",

  headers: {
    "ngrok-skip-browser-warning": true, // 외부 접근
    "Access-Control-Allow-Credentials": true, // 외부 접근
    Accept: "application/json",
    "Content-Type": "application/json",
  },
});

export default client;
