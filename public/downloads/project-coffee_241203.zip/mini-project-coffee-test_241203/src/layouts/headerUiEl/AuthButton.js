import React from "react";
import { Button, Typography, Box } from "@mui/material";
import { useNavigate } from "react-router-dom";
import { Login, Logout } from "@mui/icons-material";

export default function AuthButton() {
  const navigate = useNavigate();
  const access = sessionStorage.getItem("access");
  const refresh = sessionStorage.getItem("refresh");

  const handleLogin = () => {
    navigate("/login");
  };

  const handleLogout = () => {
    sessionStorage.clear();
    navigate("/login", { replace: true });
  };

  const buttonStyles = {
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-end",
    mr: 1.5,
  };

  const textStyles = {
    fontSize: "0.875rem",
    width: "max-content",
    marginRight: "-3px",
  };

  if (access && refresh) {
    return (
      <>
        <Button onClick={handleLogout} sx={buttonStyles} endIcon={<Logout />}>
          <Typography variant="body2" sx={textStyles}>
            로그아웃
          </Typography>
        </Button>
      </>
    );
  } else {
    return (
      <Button onClick={handleLogin} sx={buttonStyles} endIcon={<Login />}>
        <Typography variant="body2" sx={textStyles}>
          로그인
        </Typography>
      </Button>
    );
  }
}
