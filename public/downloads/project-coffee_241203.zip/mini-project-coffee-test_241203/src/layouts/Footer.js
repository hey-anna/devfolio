import React, { useState } from "react";
import { Stack, Typography, Link, Box } from "@mui/material";
import { ModalBasic } from "../components/modal/ModalBasic";
import flexBox from "../assets/styles/common/flexBox.module.css";
import colors from "../assets/styles/common/colors.module.css";
import footer from "../assets/styles/layouts/footer.module.css";
import flogo from "../assets/images/flogo.svg";
import blogo from "../assets/images/blogo.svg";

import {
  PRIVACY_POLICY,
  INTERNAL_REGULATIONS,
} from "../constants/homepageTexts";

function Copyright(props) {
  return (
    <Typography
      variant="body2"
      align="center"
      {...props}
      className={colors.textWhite}
    >
      {"Copyright © "}
      <Link color="inherit" href="http://bpnsolution.com/">
        {/* Your Website  */}
        비피앤솔루션
      </Link>
      {new Date().getFullYear()}
      {"."}
    </Typography>
  );
}

const Footer = () => {
  const [modal, setModal] = useState({ open: false, contentKey: null });

  const handleOpen = (key) => {
    setModal({ open: true, contentKey: key });
  };

  const handleClose = () => {
    setModal({ open: false, contentKey: null });
  };

  const modalContent =
    modal.contentKey === "PRIVACY_POLICY"
      ? PRIVACY_POLICY
      : INTERNAL_REGULATIONS;
  return (
    <>
      <Box
        sx={{
          bgcolor: "#29314A",
          pt: 3,
          pl: { xs: 0, md: 3 },
          pr: { xs: 0, md: 3 },
          pb: { xs: 3, md: 3 },
        }}
      >
        <Box
          sx={{
            display: "flex",
            flexDirection: { xs: "column", md: "row" },
            justifyContent: { xs: "center", md: "space-between" },
            alignItems: "center",
            height: "100%",
            width: "100%",
            pt: { xs: 0, md: 1 },
            pb: { xs: 0, md: 1 },
          }}
        >
          <Typography
            component="div"
            sx={{ pb: { xs: 3, md: 0 }, textAlign: { xs: "center" } }}
          >
            <Link href="/" underline="none">
              <img src={flogo} alt="flogo" className={footer.footerFlogo} />
            </Link>
          </Typography>
          <Stack
            direction="row"
            spacing={3}
            className={`${flexBox.flexRowAllCenter} ${colors.textWhite}`}
            sx={{ pb: { xs: 3, md: 0 } }}
          >
            <Link
              color="inherit"
              underline="hover"
              onClick={() => handleOpen("PRIVACY_POLICY")}
            >
              개인정보 처리방침
            </Link>
            <Link
              color="inherit"
              underline="hover"
              onClick={() => handleOpen("INTERNAL_REGULATIONS")}
            >
              내부관리 규정
            </Link>
          </Stack>
          <Typography
            component="div"
            sx={{ pb: { xs: 3, md: 0 }, textAlign: { xs: "center" } }}
          >
            <Link href="https://www.busan.go.kr/index" underline="none">
              <img
                src={blogo}
                alt="부산 광역시 로고"
                className={footer.footerBlogo}
              />
            </Link>
          </Typography>
        </Box>
        {/* Top 영역 */}
        <Copyright />
        {/* Copyright 영역 */}
      </Box>
      {/* Modal Dialog */}
      <ModalBasic
        open={modal.open}
        onClose={handleClose}
        title={modalContent.title}
        content={modalContent.content}
      />
    </>
  );
};

export default Footer;
