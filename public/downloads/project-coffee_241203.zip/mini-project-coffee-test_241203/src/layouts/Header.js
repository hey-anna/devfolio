import React from "react";
import { useNavigate, useLocation } from "react-router-dom";
import Link from "../components/navigation/Link";
import { Grid2, Box, Button, AppBar, Toolbar, Typography } from "@mui/material";

import { styled } from "@mui/material/styles";
import { Search, Login } from "@mui/icons-material";
import logo from "../assets/images/logo.svg";
import AuthButton from "./headerUiEl/AuthButton";

const Header = () => {
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const loader = () => {
    navigate("/login");
    console.log("loader", loader);
  };
  console.log("## pathname", pathname);

  const GradientTypography = styled(Typography)({
    background: "transparent",
    color: "transparent",
    overflow: "hidden",
    WebkitBackgroundClip: "text",
    backgroundClip: "text",
    backgroundImage: "linear-gradient(45deg, #003399 30%, #CC0066 90%)",
    "&:hover": {
      backgroundImage: "linear-gradient(45deg, #CC0066 30%, #003399 90%)",
    },
  });
  return (
    <>
      <AppBar
        position="static"
        color="default"
        elevation={0}
        sx={{ borderBottom: (theme) => `1px solid ${theme.palette.divider}` }}
      >
        <Toolbar
          sx={{
            height: "90px",
            flexWrap: "wrap",
            boxShadow: 3,

            bgcolor: (theme) =>
              theme.palette.mode === "dark" ? "#101010" : "#fff",
          }}
        >
          <Box
            sx={{
              display: "flex",
              flexDirection: "row",
              justifyContent: "space-between",
              width: "100%",
            }}
          >
            <Typography
              component="h1"
              variant="h4"
              color="inherit"
              noWrap
              flexGrow="1"
              lineHeight={0}
            >
              <Link href="/" underline="none">
                <img
                  src={logo}
                  alt="logo"
                  style={{
                    height: "100%",
                    left: "0",
                    position: "absolute",
                    top: "0",
                    paddingLeft: "24px",
                  }}
                />
              </Link>
            </Typography>
            <Box
              sx={{
                display: "flex",
                flexDirection: "row",
                justifyContent: "center",
                alignItems: "center",
                width: "100%",
              }}
            >
              <nav style={{ display: "flex", justifyContent: "center" }}>
                <Link
                  href="/intro"
                  variant="button"
                  color="text.primary"
                  sx={{ my: 1, mx: 1.5, color: "#29314A" }}
                  underline="none"
                >
                  사업소개
                </Link>
                <Link
                  href="/search"
                  variant="button"
                  color="text.primary"
                  sx={{ my: 1, mx: 1.5, color: "#29314A" }}
                  underline="none"
                >
                  생두검색
                </Link>

                <Link
                  href="/mypage"
                  variant="button"
                  color="text.primary"
                  sx={{ my: 1, mx: 1.5, color: "#29314A" }}
                  underline="none"
                >
                  My생두
                </Link>
                <Link
                  href="/statistics"
                  variant="button"
                  color="text.primary"
                  sx={{ my: 1, mx: 1.5, color: "#29314A" }}
                  underline="none"
                >
                  데이터통계
                </Link>
              </nav>
              <Button>
                <Typography>
                  Coffee
                  <GradientTypography component="span">
                    Auction
                  </GradientTypography>
                </Typography>
              </Button>
            </Box>
            <AuthButton />
          </Box>
        </Toolbar>
      </AppBar>
    </>
  );
};

export default Header;
