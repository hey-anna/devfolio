import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Box from "@mui/material/Box";
import Backdrop from "@mui/material/Backdrop";
import SpeedDial from "@mui/material/SpeedDial";
import SpeedDialIcon from "@mui/material/SpeedDialIcon";
import SpeedDialAction from "@mui/material/SpeedDialAction";
import ModalGreenBeanAdd from "./ModalGreenBeanAdd";
import { MypageDialogActions } from "../../constants/mypageTexts";

export const MypageDialog = () => {
  const access = sessionStorage.getItem("access");
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [modalType, setModalType] = useState(null);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const openModal = (type, step_type) => {
    if (!access || access === "null") {
      navigate("/login", { replace: true });
      console.log("####@@@@loader", navigate);
      return;
    }
    setModalType(type);
    handleClose();
  };
  return (
    <>
      <Box
        sx={{
          position: "fixed",
          height: 330,
          transform: "translateZ(0px)",
          flexGrow: 1,
          bottom: "5%",
          right: "1.65%",
          background: "pink",
          zIndex: 50,
        }}
      >
        <Backdrop open={open} />
        <SpeedDial
          ariaLabel="SpeedDial tooltip example"
          sx={{
            position: "absolute",
            bottom: 16,
            right: 16,
            "& > .MuiButtonBase-root": {
              backgroundColor: "#003399",
              "&:hover": {
                backgroundColor: "#003399",
              },
            },
          }}
          icon={<SpeedDialIcon />}
          onClose={handleClose}
          onOpen={handleOpen}
          open={open}
        >
          {MypageDialogActions.map((action) => (
            <SpeedDialAction
              key={action.name}
              icon={action.icon}
              tooltipTitle={action.name}
              tooltipOpen
              sx={{
                "& .MuiSpeedDialAction-staticTooltipLabel": {
                  color: "#333",
                },
              }}
              onClick={() => openModal(action.modal)}
            />
          ))}
        </SpeedDial>
      </Box>

      {modalType === "GreenBeanReg" && (
        <ModalGreenBeanAdd onClose={() => setModalType(null)} />
      )}
      {modalType === "PostRegSteps" && (
        <ModalGreenBeanAdd onClose={() => setModalType(null)} />
      )}
    </>
  );
};
