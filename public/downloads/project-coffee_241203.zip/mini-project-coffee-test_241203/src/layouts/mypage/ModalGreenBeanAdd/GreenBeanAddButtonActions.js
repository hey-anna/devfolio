import React from "react";
import { Button, Box } from "@mui/material";

const GreenBeanAddButtonActions = ({ onCancel, onAdd }) => {
  return (
    <>
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          width: "100%",
          gap: 1.5,
        }}
      >
        <Button
          onClick={onCancel}
          variant="outlined"
          sx={{
            flex: 2,
            borderColor: "#ccc",
            color: "#aaa",
          }}
        >
          취소
        </Button>
        <Button
          onClick={onAdd}
          variant="contained"
          color="primary"
          sx={{
            flex: 8,
            backgroundColor: "#003399",
          }}
        >
          등록
        </Button>
      </Box>
    </>
  );
};

export default GreenBeanAddButtonActions;
