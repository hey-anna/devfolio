import { useState, useEffect } from "react";
import { styled, alpha } from "@mui/material/styles";
import dayjs from "dayjs";
import { YearSelector } from "../../components/dates/YearSelector";
import { SearchInputBase } from "../../components/inputBases/SearchInputBase";
import ModalOrigin from "../../components/modal/ModalOrigin";
import {
  Button,
  Box,
  Grid2,
  Typography,
  Toolbar,
  FormControl,
  Select,
  MenuItem,
  Collapse,
} from "@mui/material";
import flexBox from "../../assets/styles/common/flexBox.module.css";
import { Add, Close } from "@mui/icons-material";
import SearchIcon from "@mui/icons-material/Search";
import RefreshRoundedIcon from "@mui/icons-material/RefreshRounded";

const SearchBgColor = styled("div")(({ theme }) => ({
  position: "relative",
  borderRadius: theme.shape.borderRadius,
  backgroundColor: alpha(theme.palette.common.white, 0.15),
  "&:hover": {
    backgroundColor: alpha(theme.palette.common.white, 0.25),
  },
  "&:focus": {
    backgroundColor: alpha(theme.palette.common.white, 0.25),
  },
  marginRight: theme.spacing(1),
  marginLeft: 0,
  width: "100%",
  [theme.breakpoints.up("sm")]: {
    marginLeft: theme.spacing(3),
    width: "auto",
  },
}));

const SearchIconWrapper = styled("div")(({ theme }) => ({
  padding: theme.spacing(0, 2),
  height: "100%",
  position: "absolute",
  pointerEvents: "none",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  zIndex: "1",
}));

const ToolbarSx = styled(Toolbar)(({ theme, customStyle }) => ({
  minHeight: "unset !important",
  marginBottom: 8,
  marginLeft: 0,
  padding: "0px !important",
  "& .MuiInputBase-root :focus": {
    background: "#fff",
    marginLeft: 0,
  },
  boxShadow: "none",
  "& > div": {
    marginLeft: "0",
    border: "1px solid #b7b6b6b3",
    borderRadius: "4px",
  },
  "& > div:focus": {},
  "& > div:hover": {
    border: "1px solid #29304a ",
  },
  "& .MuiInputBase-input": {},
  "& .MuiInputBase-input:focus": {
    border: "1px solid #29304a ",
  },
  ...customStyle,
}));

export const MyPageProductSearchForm = ({
  onSearch,
  selectedOrigin,
  onFinalClickInfoChange,
  value,
  formData,
  onInputChange,
  onDateChange,
  onYearChange,
  onReset,
  onKeyPress,
  searchResultsCount,
  processingTypes,
}) => {
  const [open, setOpen] = useState(false);
  const [isOpenModalOriginSelect, setIsOpenModalOriginSelect] = useState(false);
  const handleToggle = () => {
    setOpen(!open);
  };
  const handleClickOpen = (params) => {
    setIsOpenModalOriginSelect(true);
  };
  const handleClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }
    setIsOpenModalOriginSelect(false);
  };

  const SearchBtn = styled(Button)({
    width: "100%",
    boxShadow: "none",
    textTransform: "none",
    fontSize: "1.125rem",
    minHeight: "unset",
    backgroundColor: "#ebebebb3",
    borderColor: "#b7b6b6b3",
    justifyContent: "space-between",
    color: "#999",
    "&:hover": {
      backgroundColor: "rgb(235,235,235,0.9)",
      boxShadow: "none",
    },
  });

  const IconSx = {
    color: "#000000de",
    root: {},
  };

  return (
    <>
      <Box sx={{ width: 1, mb: 2 }}>
        <Grid2 container spacing={1}>
          <Grid2 size={{ xs: 12, sm: 8, md: 3 }}>
            <ToolbarSx>
              <SearchBgColor sx={{ flexGrow: 1 }}>
                <SearchInputBase
                  name="CoffeeName"
                  value={formData.CoffeeName}
                  placeholder="생두 이름 입력"
                  inputProps={{ "aria-label": "검색하기" }}
                  onChange={onInputChange}
                  onKeyDown={onKeyPress}
                />
              </SearchBgColor>
            </ToolbarSx>
          </Grid2>
          {/* 생두 이름 입력 E */}
          <Grid2 size={{ xs: 12, sm: 8, md: 3 }}>
            <ToolbarSx>
              <SearchBgColor sx={{ flexGrow: 1 }}>
                <SearchInputBase
                  name="BeanVariety"
                  value={formData.BeanVariety}
                  placeholder="생두 품종 입력"
                  inputProps={{ "aria-label": "검색하기" }}
                  onChange={onInputChange}
                  onKeyDown={onKeyPress}
                />
              </SearchBgColor>
            </ToolbarSx>
          </Grid2>
          {/* 생두 품종 입력 E */}
          <Grid2 size={{ xs: 12, sm: 8, md: 1.8 }} sx={{ pr: 1 }}>
            <ToolbarSx>
              <SearchBtn
                name="ProductionCountryCode"
                value={formData.ProductionCountryCode}
                onClick={handleClickOpen}
                onChange={onInputChange}
                variant="outlined"
                endIcon={<SearchIcon sx={IconSx} />}
              >
                {selectedOrigin.name || "원산지 선택"}
              </SearchBtn>
            </ToolbarSx>
          </Grid2>
          {/* 원산지 입력 E */}
          <Grid2 size={{ xs: 12, sm: 8, md: 1.8 }}>
            <ToolbarSx
              customStyle={{
                border: "none",
                "& > div": { border: 0 },
                "& > div:hover": {
                  border: 0,
                },
              }}
            >
              <YearSelector
                views={["year"]}
                openTo="year"
                minDate={dayjs("2000-01-01")}
                maxDate={dayjs("2030-12-31")}
                defaultValue={null}
                name="ProductionYear"
                onChange={onYearChange}
                value={
                  formData.ProductionYear
                    ? dayjs(`${formData.ProductionYear}-01-01`)
                    : null
                }
                placeholder={value ? "undefined" : "생산년도 입력"}
                sx={{
                  "& .MuiInputBase-input": {
                    fontSize: "1.125rem",
                    p: 1,
                    pl: 2,
                  },
                }}
              />
            </ToolbarSx>
          </Grid2>
          {/* 생산년도 */}

          <Grid2
            size={{ xs: 12, sm: 8, md: 2.4 }}
            sx={{ display: "flex", justifyContent: "right" }}
          >
            <ToolbarSx>
              <Button
                onClick={handleToggle}
                variant="contained"
                size="large"
                sx={{
                  fontsize: "1.125rem",
                  pt: 1.125,
                  pb: 1.125,
                  color: "#333",
                  backgroundColor: "#fff !important",
                  border: "1px solid #b7b6b6b3",
                }}
                startIcon={!open ? <Add /> : <Close />}
              >
                상세검색
              </Button>
            </ToolbarSx>
          </Grid2>
        </Grid2>
        <Collapse in={open}>
          <Grid2 container spacing={1}>
            <Grid2 size={{ xs: 12, sm: 8, md: 3 }}>
              <ToolbarSx>
                <SearchBgColor sx={{ flexGrow: 1 }}>
                  <SearchInputBase
                    name="Farm"
                    value={formData.Farm}
                    placeholder="생산농장 입력"
                    inputProps={{ "aria-label": "검색하기" }}
                    onChange={onInputChange}
                    onKeyDown={onKeyPress}
                  />
                </SearchBgColor>
              </ToolbarSx>
            </Grid2>
            {/* 생산농장 E */}
            <Grid2 size={{ xs: 12, sm: 8, md: 1.5 }}>
              <ToolbarSx>
                <SearchBgColor sx={{ flexGrow: 1 }}>
                  <SearchInputBase
                    name="Altitude"
                    value={formData.Altitude}
                    placeholder="생산고도 입력"
                    inputProps={{ "aria-label": "검색하기" }}
                    onChange={onInputChange}
                    onKeyDown={onKeyPress}
                  />
                </SearchBgColor>
              </ToolbarSx>
            </Grid2>
            {/* 생산고도 E */}
            <Grid2 size={{ xs: 12, sm: 2 }} sx={{ pr: 1 }}>
              <FormControl fullWidth>
                <Select
                  name="ProcessingCode"
                  value={formData.ProcessingCode || ""}
                  onChange={onInputChange}
                  displayEmpty
                  inputProps={{ "aria-label": "Without label" }}
                  renderValue={(value) =>
                    value !== "" ? (
                      value
                    ) : (
                      <span style={{ color: "rgba(0, 0, 0, 0.38)" }}>
                        가공방식 선택
                      </span>
                    )
                  }
                  sx={{
                    "& .MuiInputBase-input": {
                      fontSize: "1.125rem",
                      lineHeight: "normal",
                      display: "flex",
                      alignItems: "center",
                      p: 1.125,
                      pl: 2,
                    },
                  }}
                >
                  <MenuItem value="" disabled>
                    가공방식 선택
                  </MenuItem>
                  {Object.entries(processingTypes).map(([key, type]) => (
                    <MenuItem key={key} value={type}>
                      {type}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid2>
            {/* 가공방식 선택 */}
            <Grid2 size={{ xs: 12, sm: 2 }}>
              <ToolbarSx
                customStyle={{
                  border: "none",
                  "& > div": { border: 0 },
                  "& > div:hover": {
                    border: 0,
                  },
                }}
              >
                <YearSelector
                  views={["year", "month", "day"]}
                  openTo="year"
                  minDate={dayjs("2000-01-01")}
                  maxDate={dayjs("2030-12-31")}
                  defaultValue={null}
                  name="StockDate"
                  placeholder="입고일자 입력"
                  value={formData.StockDate ? dayjs(formData.StockDate) : null}
                  onChange={(newValue) => onDateChange(newValue, "stockDate")}
                  sx={{
                    "& .MuiInputBase-input": {
                      fontSize: "1.125rem",
                      p: 1,
                      pl: 2,
                    },
                  }}
                />
              </ToolbarSx>
            </Grid2>
            {/* 입고일자 E */}
            <Grid2 size={{ xs: 12, sm: 4 }}>
              <ToolbarSx>
                <Button
                  onClick={onReset}
                  variant="contained"
                  sx={{
                    height: "43.88px",
                    boxShadow: "none",
                    padding: "6px 9.57px",
                    color: "#000000de",
                    backgroundColor: "#fff",
                  }}
                  startIcon={<RefreshRoundedIcon sx={{ color: "#000000de" }} />}
                >
                  초기화
                </Button>
              </ToolbarSx>
            </Grid2>
          </Grid2>
        </Collapse>

        <Box className={flexBox.flexRow} sx={{ mt: 8 }}>
          <Typography sx={{ flexGrow: 1, textAlign: "center" }} variant="h4">
            조회 결과 : {searchResultsCount} 건
          </Typography>
          <Button
            onClick={onSearch}
            variant="contained"
            sx={{
              height: "43.88px",
              boxShadow: "none",
              backgroundColor: "#333",
            }}
            startIcon={<SearchIcon sx={{ color: "#fff" }} />}
          >
            조회
          </Button>
        </Box>
      </Box>
      {isOpenModalOriginSelect && (
        <ModalOrigin
          isOpen={isOpenModalOriginSelect}
          handleClose={handleClose}
          onFinalClickInfoChange={onFinalClickInfoChange}
        />
      )}
    </>
  );
};
