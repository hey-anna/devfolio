import React, { useEffect, useRef, useState, useContext } from "react";
import dayjs from "dayjs";
import { styled } from "@mui/material/styles";
import {
  Container,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Typography,
  Slide,
  AppBar,
  Toolbar,
  IconButton,
  FormControl,
  MenuItem,
  Select,
} from "@mui/material";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import { BeanInputBase } from "../../components/inputBases/BeanInputBase";
import GreenBeanAddButtonActions from "./ModalGreenBeanAdd/GreenBeanAddButtonActions";
import { useAddGreenBeanMutation } from "../../hooks/useMypage/useAddGreenBeanMutation";
import ModalOrigin from "../../components/modal/ModalOrigin";
import OriginInputBase from "../../components/inputBases/OriginInputBase";
import BeanYearSelector from "../../components/inputBases/BeanYearSelector";
import BeanDateSelector from "../../components/inputBases/BeanDateSelector";
import { processingTypes } from "../../constants/searchpageTexts";

const dateInputStyle = {
  "& .MuiFormControl-root": {
    width: "100%",
    border: 0,
    "&:hover": {
      border: 0,
    },
    "& .MuiInputBase-input": {
      fontSize: "1.125rem",
      padding: "8px 8px 8px 0",
      paddingLeft: `calc(1em - 4px)`,
      paddingRight: `calc(1em + 4px)`,
      transition: "width 0.3s ease",
    },
  },
};

const ToolbarSx = styled(Toolbar)(({ theme, customStyle }) => ({
  width: "100%",
  minHeight: "unset !important",
  marginBottom: 12,
  marginLeft: 0,
  padding: "0px !important",
  "& .MuiInputBase-root :focus": {
    background: "#fff",
    marginLeft: 0,
  },
  boxShadow: "none",
  "& > div": {
    marginLeft: "0",
    border: "1px solid #b7b6b6b3",
    borderRadius: "4px",
  },
  "& > div:focus": {},
  "& > div:hover": {
    border: "1px solid #29304a ",
  },
  "& .MuiInputBase-input": {},
  "& .MuiInputBase-input:focus": {
    border: "1px solid #29304a ",
  },
  ...customStyle,
}));
const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

const ModalGreenBeanAdd = ({ onClose, onAdd }) => {
  const { mutate: addGreenBean } = useAddGreenBeanMutation();

  const [beanData, setBeanData] = useState({
    CoffeeName: "",
    BeanVariety: "",
    ProductionCountryCode: "",
    ProductionYear: "",
    Altitude: "",
    Farm: "",
    StockDate: "",
    ProcessingCode: "",
    Company: "",
    Weight: "",
  });

  const [isOpenModalOriginSelect, setIsOpenModalOriginSelect] = useState(false);
  const [selectedOriginValue, setSelectedOriginValue] = useState({
    code: "",
    name: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setBeanData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleAdd = () => {
    addGreenBean(beanData, {
      onSuccess: () => {
        alert("## 커피 신규 등록이 완료 되었습니다.");
        onClose();
      },
    });
  };

  const handleClickOpen = (params) => {
    setIsOpenModalOriginSelect(true);
  };

  const handleClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }
    setIsOpenModalOriginSelect(false);
  };

  const handleOriginSelect = (originData) => {
    console.log("##@@Received origin data:", originData);
    setSelectedOriginValue({
      code: originData.originCode,
      name: originData.originName,
    });
    setBeanData((prev) => ({
      ...prev,
      ProductionCountryCode: originData.originCode,
    }));
  };

  const handleYearChange = (newValue) => {
    const yearDate = dayjs(newValue).startOf("year");
    if (yearDate.isValid()) {
      const yearAsNumber = parseInt(yearDate.format("YYYY"), 10);
      setBeanData((prevFormData) => ({
        ...prevFormData,
        ProductionYear: yearAsNumber,
      }));
    } else {
      console.error("Invalid date provided");
    }
  };

  const handleDateChange = (newValue) => {
    const date = dayjs(newValue);
    if (date.isValid()) {
      const formattedDate = date.format("YYYYMMDD");
      setBeanData((prevFormData) => ({
        ...prevFormData,
        StockDate: formattedDate,
      }));
    } else {
      console.error("Invalid date provided");
    }
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    console.log(`Input changed - ${name}: ${value}`); // 입력 값 로깅
    setBeanData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };
  return (
    <>
      <Dialog
        fullScreen
        open={true}
        onClose={onClose}
        aria-labelledby="draggable-dialog-title"
      >
        <AppBar
          sx={{
            position: "relative",
            boxShadow: 0,
            borderBottom: "1px solid #ccc",
          }}
        >
          <Toolbar
            sx={{
              background: "#fff",
            }}
          >
            <IconButton
              edge="start"
              color="#9e9e9e"
              onClick={onClose}
              aria-label="close"
            >
              <ArrowBackIcon />
            </IconButton>
            <Typography
              sx={{
                ml: 2,
                flex: 1,
                color: "#000000de",
              }}
              variant="h6"
              component="div"
            >
              나가기
            </Typography>
          </Toolbar>
        </AppBar>
        <Container sx={{ pt: 8, pb: 6 }} maxWidth="sm">
          <DialogTitle
            component="h1"
            variant="h6"
            style={{ cursor: "move" }}
            id="draggable-dialog-title"
          >
            커피 신규 등록
          </DialogTitle>
          {/* 타이틀 */}
          <DialogContent>
            <ToolbarSx>
              <BeanInputBase
                name="CoffeeName"
                value={beanData.CoffeeName}
                onChange={handleChange}
                placeholder="생두 이름을 입력하세요."
              />
            </ToolbarSx>
            {/* 생두이름 E */}
            <ToolbarSx>
              <BeanInputBase
                name="BeanVariety"
                value={beanData.BeanVariety}
                onChange={handleChange}
                placeholder="생두 품종을 입력하세요."
              />
            </ToolbarSx>
            {/* 생두품종 E */}
            <ToolbarSx>
              <OriginInputBase
                selectedOrigin={selectedOriginValue}
                onClick={handleClickOpen}
                value={beanData.ProductionCountryCode}
              />
            </ToolbarSx>
            {/* 원산지 선택 E */}
            <ToolbarSx>
              <BeanYearSelector
                value={
                  beanData.ProductionYear
                    ? dayjs(`${beanData.ProductionYear}-01-01`)
                    : null
                }
                onChange={handleYearChange}
              />
            </ToolbarSx>
            {/* 생산년도 선택 E */}
            <ToolbarSx>
              <BeanInputBase
                name="Altitude"
                value={beanData.Altitude}
                onChange={handleChange}
                placeholder="고도 입력 (ex - 1900, 1900-2000)"
              />
            </ToolbarSx>
            {/* 고도 입력 E */}
            <ToolbarSx customStyle={dateInputStyle}>
              <BeanDateSelector onChange={handleDateChange} />
            </ToolbarSx>
            {/* 입고 일자 선택 E */}
            <ToolbarSx sx={dateInputStyle}>
              <FormControl>
                <Select
                  name="ProcessingCode"
                  value={beanData.ProcessingCode || ""}
                  onChange={handleInputChange}
                  displayEmpty
                  inputProps={{ "aria-label": "Without label" }}
                  renderValue={(value) =>
                    value ? (
                      processingTypes[value]
                    ) : (
                      <span style={{ color: "rgba(0, 0, 0, 0.38)" }}>
                        가공방식 선택
                      </span>
                    )
                  }
                  sx={{
                    "& .MuiInputBase-input": {
                      fontSize: "1.125rem",
                      lineHeight: "normal",
                      display: "flex",
                      alignItems: "center",
                      p: 1.125,
                      pl: 2,
                    },
                  }}
                >
                  <MenuItem value="" disabled>
                    가공방식 선택
                  </MenuItem>
                  {Object.entries(processingTypes).map(([key, type]) => (
                    <MenuItem key={key} value={key}>
                      {type}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </ToolbarSx>
            {/* 가공 방식 선택 E */}
            <ToolbarSx>
              <BeanInputBase
                name="Company"
                value={beanData.Company}
                onChange={handleChange}
                placeholder="수입 회사를 입력하세요."
              />
            </ToolbarSx>
            {/* 수입 회사 입력 E */}
            <ToolbarSx>
              <BeanInputBase
                name="Weight"
                value={beanData.Weight}
                onChange={handleChange}
                placeholder="수입 무게를 입력하세요."
              />
            </ToolbarSx>
            {/* 수입 무게 입력 E */}
            <ToolbarSx>
              <BeanInputBase
                name="Farm"
                value={beanData.Farm}
                onChange={handleChange}
                placeholder="수입 농장을 입력하세요."
              />
            </ToolbarSx>
            {/* 생산 농장 입력 E */}
          </DialogContent>
          <DialogActions
            sx={{
              pl: 3,
              pr: 3,
            }}
          >
            <GreenBeanAddButtonActions onCancel={onClose} onAdd={handleAdd} />
          </DialogActions>
        </Container>
      </Dialog>
      {isOpenModalOriginSelect && (
        <ModalOrigin
          isOpen={isOpenModalOriginSelect}
          handleClose={handleClose}
          onFinalClickInfoChange={handleOriginSelect}
        />
      )}
    </>
  );
};

export default ModalGreenBeanAdd;
