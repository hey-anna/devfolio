import React, { useState, useContext } from "react";
import { Box, Container } from "@mui/material";
import ProductDataGrid from "../../components/dataGrid/ProductDataGrid"; //
import BasicTooltip from "../../components/tooltips/BasicTooltip";
import dayjs from "dayjs";
import isSameOrBefore from "dayjs/plugin/isSameOrBefore";
import isSameOrAfter from "dayjs/plugin/isSameOrAfter";
import { useSearchQuery } from "../../hooks/useSearch/useSearchQuery";
import { processingTypes } from "../../constants/searchpageTexts";

dayjs.extend(isSameOrBefore);
dayjs.extend(isSameOrAfter);

export const MyPageProductDataArea = ({ greenBeansData }) => {
  const formattedData = greenBeansData?.map((beanData, index) => ({
    id: index + 1,
    CoffeeKey: beanData.CoffeeKey, // 커피 키
    CoffeeName: beanData.CoffeeName, // 생두이름
    BeanVariety: beanData.BeanVariety, // 생두품종
    CountryNameEng: beanData.CountryNameEng, // 원산지
    ProductionYear: beanData.ProductionYear, // 생산년도
    Altitude: beanData.Altitude, // 고도
    StockDate: `${dayjs(beanData.StockDate).format("YYYY-MM-DD")}`, // 입고일자
    ProcessingCode: beanData.ProcessingCode, // 가공방식
    Company: beanData.Company, // 수입회사
    Weight: beanData.Weight, // 수입무게
    Farm: beanData.Farm, // 생산농장
  }));

  const columns = [
    {
      field: "id",
      headerName: "No.",
      flex: 0.1,
    },
    {
      field: "CoffeeKey",
      headerName: "커피키",
      flex: 1.5,
      renderCell: (params) => <BasicTooltip title={params.row.CoffeeKey} />,
      valueGetter: ({ value }) => value || "-",
    },
    {
      field: "CoffeeName",
      headerName: "생두이름",
      flex: 1.25,
      renderCell: (params) => <BasicTooltip title={params.row.CoffeeName} />,
    },
    {
      field: "BeanVariety",
      headerName: "생두품종",
      flex: 1.25,
      renderCell: (params) => <BasicTooltip title={params.row.BeanVariety} />,
    },
    {
      field: "CountryNameEng",
      headerName: "원산지",
      flex: 1.65,
      renderCell: (params) => (
        <BasicTooltip title={params.row.CountryNameEng} />
      ),
    },
    {
      field: "ProductionYear",
      headerName: "생산년도",
      flex: 1,
      renderCell: (params) => (
        <BasicTooltip title={params.row.ProductionYear} />
      ),
    },
    {
      field: "Altitude",
      headerName: "고도",
      flex: 1.25,
      renderCell: (params) => <BasicTooltip title={params.row.Altitude} />,
    },
    {
      field: "StockDate",
      headerName: "입고일자",
      flex: 1.25,
      renderCell: (params) => <BasicTooltip title={params.row.StockDate} />,
    },
    {
      field: "ProcessingCode",
      headerName: "가공방식",
      flex: 1.25,
      renderCell: (params) => {
        const processingName =
          processingTypes[params.row.ProcessingCode] || "Unknown";
        return <BasicTooltip title={processingName} />;
      },
    },
    {
      field: "Company",
      headerName: "수입회사",
      flex: 1.25,
      renderCell: (params) => <BasicTooltip title={params.row.Company} />,
    },
    {
      field: "Weight",
      headerName: "수입무게",
      flex: 1,
      renderCell: (params) => <BasicTooltip title={params.row.Weight} />,
    },
    {
      field: "Farm",
      headerName: "생산농장",
      flex: 1.25,
      renderCell: (params) => <BasicTooltip title={params.row.Farm} />,
    },
  ];

  const datagridSx = {
    border: "0",
    "& .MuiDataGrid-root": {
      border: "0px !important",
    },
    "& .MuiDataGrid-main": {},
    "& .MuiDataGrid-root--densityStandard": {},
    "& .MuiDataGrid-withBorderColor": {
      border: 0,
    },
    '& div[data-rowIndex][role="row"]:nth-of-type(5n-4)': {
      "& div": {},
    },
    "& .MuiDataGrid-virtualScrollerRenderZone": {
      "& .MuiDataGrid-row": {
        "&:nth-of-type(2n)": { backgroundColor: "rgba(238, 242, 245, 1)" },
        cursor: "pointer",
      },
    },
    "& .MuiDataGrid-cell:nth-of-type(7)": {
      "& .MuiDataGrid-cellContent": {
        borderBottom: "1px solid #000",
      },
    },
    "& .disabled-cell": {
      pointerEvents: "none",
      color: "rgba(0, 0, 0, 0.26)",
      "& .MuiDataGrid-cellContent": {
        borderBottom: "0 !important",
      },
    },
    "&.MuiDataGrid-root .MuiDataGrid-cell:focus-within": {
      outline: "none !important",
    },
    "& .MuiDataGrid-columnHeaders": {
      fontSize: 14,
      minHeight: "55px !important",
      maxHeight: "55px !important",
      lineHeight: "55px !important",
      borderTop: "#29314A 3px solid",
      borderBottom: "#29314A 3px solid",
      borderRadius: "0px !important",
    },
    "& .MuiDataGrid-footerContainer": {
      fontSize: 14,
      minHeight: "40px !important",
      maxHeight: "40px !important",
      lineHeight: "40px !important",
    },
  };

  return (
    <>
      <Box>
        <Container sx={{ p: "0 !important" }}>
          <Box>
            <ProductDataGrid
              rows={formattedData || []}
              columns={columns}
              getRowId={(row) => row.contract_sub_id}
              sx={datagridSx}
            />
          </Box>
        </Container>
      </Box>
    </>
  );
};
