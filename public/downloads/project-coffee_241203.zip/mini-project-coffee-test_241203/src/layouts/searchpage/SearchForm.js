import React, { useEffect, useState } from "react";
import { Box, TextField, InputAdornment, IconButton } from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import ReplayIcon from "@mui/icons-material/Replay";
import { useNavigate, useLocation } from "react-router-dom";

export const SearchForm = ({ onSearch }) => {
  const navigate = useNavigate();
  const [keyword, setKeyword] = useState("");

  const searchByKeyword = (e) => {
    e.preventDefault();
    onSearch(keyword);
    console.log("@@@ 검색 키워드:", keyword, onSearch);
    navigate(`?q=${encodeURIComponent(keyword)}`, { replace: true }); //
  };

  const handleClearInput = () => {
    setKeyword("");
    navigate("/search", { replace: true });
  };

  return (
    <Box sx={{ mt: 12, mb: 12 }}>
      <form onSubmit={searchByKeyword} style={{ width: "100%" }}>
        <TextField
          value={keyword}
          onChange={(e) => setKeyword(e.target.value)}
          fullWidth
          id="search"
          type="search"
          variant="outlined"
          placeholder="생두이름을 입력해주세요."
          sx={{
            minWidth: 280,
            borderRadius: 50,
            "& .MuiOutlinedInput-root": {
              borderRadius: 50,
              height: 70,
            },
          }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <IconButton type="submit" aria-label="search">
                  <SearchIcon />
                </IconButton>
              </InputAdornment>
            ),
            endAdornment: keyword && (
              <InputAdornment position="end">
                <IconButton onClick={handleClearInput} aria-label="clear input">
                  <ReplayIcon sx={{ color: "#aaa" }} fontSize="large" />
                </IconButton>
              </InputAdornment>
            ),
          }}
        />
      </form>
    </Box>
  );
};
