import React, { useEffect, useState } from "react";
import { Box, Grid2, Button, Tooltip } from "@mui/material";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import { TastePotentialGraph } from "./graphs/TastePotentialGraph/TastePotentialGraph";
import { ComparativeGraph } from "./graphs/ComparativeGraph/ComparativeGraph";
import { AromaPotentialGraph } from "./graphs/AromaPotentialGraph/AromaPotentialGraph";
import { BarGraph } from "./graphs/BarGraph/BarGraph";
import BarGraphTable from "../../detailpage/BarGraphTable";
import IconButton from "@mui/material/IconButton";
import InfoIcon from "@mui/icons-material/Info";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";

export const ProductDetailGraphArea = ({
  dataAnalysisInfo,
  dataAvgAnalysisInfo,
}) => {
  const theme = createTheme({
    components: {
      MuiTooltip: {
        styleOverrides: {
          tooltip: {
            maxWidth: "none",
            backgroundColor: "transparent",
            color: "white",
          },
          popper: {
            width: "50%",
          },
          arrow: {
            color: "#EFF2F4",
          },
        },
      },
    },
  });
  return (
    <Box sx={{ mt: 8 }}>
      <Grid2 container spacing={5}>
        <Grid2 size={{ xs: 12, sm: 8, md: 4 }} sx={{ backgroundColor: "" }}>
          <TastePotentialGraph
            acidityPotential={dataAnalysisInfo.AcidityPotential}
            sweetnessPotential={dataAnalysisInfo.SweetnessPotential}
            aromaPotential={dataAnalysisInfo.AromaPotential}
            bodyPotential={dataAnalysisInfo.BodyPotential}
            bitternessPotential={dataAnalysisInfo.BitternessPotential}
          />
        </Grid2>
        <Grid2 size={{ xs: 12, sm: 8, md: 4 }}>
          <ComparativeGraph
            acidityPotential={dataAnalysisInfo.AcidityPotential}
            sweetnessPotential={dataAnalysisInfo.SweetnessPotential}
            aromaPotential={dataAnalysisInfo.AromaPotential}
            bodyPotential={dataAnalysisInfo.BodyPotential}
            bitternessPotential={dataAnalysisInfo.BitternessPotential}
            dataAvgAnalysisInfo={dataAvgAnalysisInfo}
          />
        </Grid2>
        <Grid2 size={{ xs: 12, sm: 8, md: 4 }}>
          <AromaPotentialGraph
            dataAnalysisInfo={dataAnalysisInfo}
            chlorogenicAcids={dataAnalysisInfo.ChlorogenicAcids}
            sucrose={dataAnalysisInfo.Sucrose}
            monoSugar={dataAnalysisInfo.MonoSugar}
            diterpene={dataAnalysisInfo.Diterpene}
            trigonelline={dataAnalysisInfo.Trigonelline}
            organicAcids={dataAnalysisInfo.OrganicAcids}
          />
        </Grid2>
      </Grid2>

      <Grid2
        container
        sx={{
          position: "relative",
        }}
      >
        <BarGraph dataAnalysisInfo={dataAnalysisInfo} />
        <ThemeProvider theme={theme}>
          <Tooltip
            title={<BarGraphTable />}
            arrow
            placement="left-end"
            sx={{
              position: "absolute",
              top: "0",
              right: "5%",
            }}
            PopperProps={{
              modifiers: [
                {
                  name: "flip",
                  enabled: true,
                  options: {
                    altBoundary: true,
                    rootBoundary: "viewport",
                  },
                },
                {
                  name: "preventOverflow",
                  options: {
                    altAxis: true,
                    altBoundary: true,
                    tether: true,
                    rootBoundary: "document",
                  },
                },
              ],
            }}
          >
            <IconButton>
              <InfoOutlinedIcon fontSize="large" sx={{ color: "#A2A2A2" }} />
            </IconButton>
          </Tooltip>
        </ThemeProvider>
      </Grid2>
    </Box>
  );
};
