import React, { useEffect, useRef } from "react";
import * as echarts from "echarts";

export const AromaPotentialGraph = ({ dataAnalysisInfo }) => {
  const chartRef = useRef(null);
  const myChart = useRef(null);
  useEffect(() => {
    if (chartRef.current && !myChart.current) {
      myChart.current = echarts.init(chartRef.current);
    }
    const categories = [
      "Sucrose",
      "Mono\nsugar",
      "Diterpene",
      "Trigonelline",
      "Organic\nacids",
      "Chlorogenic\nacids",
    ];
    const values = [
      dataAnalysisInfo.ChlorogenicAcids,
      dataAnalysisInfo.Sucrose,
      dataAnalysisInfo.MonoSugar,
      dataAnalysisInfo.Diterpene,
      dataAnalysisInfo.Trigonelline,
      dataAnalysisInfo.OrganicAcids,
    ];
    console.log("## values", values);
    const option = {
      title: {
        text: "Aroma Potential",
      },
      polar: {
        radius: [22, "68%"],
      },
      radiusAxis: {
        max: 1,
      },
      angleAxis: {
        type: "category",
        data: categories,
        startAngle: 90,
        axisLine: {
          show: true,
          lineStyle: {
            color: "#ddd",
            width: 1,
            type: "solid",
          },
        },
        axisLabel: {
          color: "#333",
          fontSize: "11",
          verticalAlign: "top",
          align: "right",
        },
      },
      tooltip: {},
      series: [
        {
          type: "bar",

          data: values,
          coordinateSystem: "polar",

          itemStyle: {
            color: (params) => {
              const colors = [
                "rgba(60, 87, 102, 0.915)",
                "rgba(134, 120, 81, 0.915)",
                "rgba(193, 146, 65, 0.915)",
                "rgba(252, 150, 82, 0.915)",
                "rgba(199, 75, 89, 0.915)",
                "rgba(199, 75, 89, 0.915)",
              ];
              return colors[params.dataIndex];
            },
          },
        },
      ],
      animation: false,
    };

    if (myChart.current) {
      myChart.current.setOption(option);
    }

    return () => {
      myChart.current && myChart.current.dispose();
      myChart.current = null;
    };
  }, [dataAnalysisInfo]);

  return <div ref={chartRef} style={{ width: "100%", height: "400px" }} />;
};
