import React, { useEffect, useRef } from "react";
import * as echarts from "echarts";

export const BarGraph = ({ dataAnalysisInfo }) => {
  const chartRef = useRef(null);
  const myChart = useRef(null);
  useEffect(() => {
    if (!myChart.current && chartRef.current) {
      myChart.current = echarts.init(chartRef.current);
    }
    const MAX = 1;
    const categories = [
      "Organic-acids",
      "Sucrose",
      "Mono-sugar",
      "Amino-acids",
      "Poly-sugar",
      "Lipids",
      "Diterpene",
      "Water",
      "Chlorogenic-acids",
      "Caffeine",
      "Caffeine-sub",
      "Trigonelline",
    ];
    const values = [
      dataAnalysisInfo.OrganicAcids,
      dataAnalysisInfo.Sucrose,
      dataAnalysisInfo.MonoSugar,
      dataAnalysisInfo.AminoAcids,
      dataAnalysisInfo.PolySugar,
      dataAnalysisInfo.Lipids,
      dataAnalysisInfo.Diterpene,
      dataAnalysisInfo.Water,
      dataAnalysisInfo.ChlorogenicAcids,
      dataAnalysisInfo.Caffeine,
      dataAnalysisInfo.CaffeineSub,
      dataAnalysisInfo.Trigonelline,
    ];
    const colors = [
      "#EA96A0",
      "#e19153",
      "#b89c49",
      "#98a246",
      "#60ae47",
      "#4aae8a",
      "#4baba4",
      "#50abbc",
      "#6daee2",
      "#b6a8eb",
      "#df8fe7",
      "#e890c6",
    ];

    console.log("## values", values);
    const option = {
      title: {
        text: "Bar Graph",
      },
      xAxis: {
        type: "category",
        data: categories,
        axisLabel: {
          interval: 0,
          textStyle: {
            fontSize: 12,
          },
        },
        axisTick: {
          show: false,
        },
      },
      grid: {
        left: "0%",
        right: "0%",
        containLabel: true,
      },
      yAxis: {
        type: "value",
        axisLine: {
          show: true,
          lineStyle: {
            color: "black",
            width: 1,
          },
        },
        splitLine: {
          show: false,
        },
      },

      series: [
        {
          data: values.map((value, index) => ({
            value: value,
            itemStyle: {
              color: colors[index],
            },
          })),
          type: "bar",
        },
      ],
    };
    if (myChart.current) {
      myChart.current.setOption(option);
    }
    return () => {
      myChart.current && myChart.current.dispose();
      myChart.current && myChart.current.dispose();
      myChart.current = null;
    };
  }, [dataAnalysisInfo]);
  return <div ref={chartRef} style={{ width: "100%", height: "400px" }} />;
};
