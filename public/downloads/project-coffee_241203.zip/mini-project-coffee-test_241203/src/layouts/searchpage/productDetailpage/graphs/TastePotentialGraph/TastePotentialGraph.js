import React, { useEffect, useRef } from "react";
import * as echarts from "echarts";

export const TastePotentialGraph = ({
  acidityPotential = 0,
  sweetnessPotential = 0,
  aromaPotential = 0,
  bodyPotential = 0,
  bitternessPotential = 0,
}) => {
  console.log(
    "Props in AromaPotentialGraph:",
    acidityPotential,
    sweetnessPotential,
    aromaPotential,
    bodyPotential,
    bitternessPotential,
  );
  const chartRef = useRef(null);
  const myChart = useRef(null);
  const MAX = 10;
  const textColor = "#333";

  useEffect(() => {
    if (chartRef.current) {
      myChart.current = echarts.init(chartRef.current);
    }

    const option = {
      title: {
        text: "Taste Potential",
        textStyle: {
          color: "#333",
        },
      },

      radar: {
        splitNumber: 5,
        radius: "68%",
        indicator: [
          {
            name: "Acidity\npotential",
            max: MAX,
            nameLocation: "end",
            axisLabel: {
              show: true,
            },
            nameTextStyle: { color: textColor },
          },
          {
            name: "Sweetness\npotential",

            max: MAX,
            nameTextStyle: { color: textColor },
          },
          {
            name: "Aroma\npotential",
            max: MAX,
            nameTextStyle: { color: textColor },
          },
          {
            name: "Body\npotential",
            max: MAX,
            nameTextStyle: { color: textColor },
          },
          {
            name: "Bitterness\npotential",
            max: MAX,
            nameTextStyle: { color: textColor },
          },
        ],
        splitArea: {
          show: true,
          areaStyle: {
            color: ["rgba(255, 255, 255, 0)"],
          },
        },
        axisLine: {
          show: true,
          lineStyle: {
            color: "#ddd",
            width: 1,
            type: "solid",
          },
        },
        axisLabel: {
          color: "#333",
          fontSize: "11",
          verticalAlign: "top",
          align: "right",
        },
      },

      series: [
        {
          name: "Budget vs spending",
          type: "radar",
          symbol: "none",
          data: [
            {
              value: [
                acidityPotential,
                sweetnessPotential,
                aromaPotential,
                bodyPotential,
                bitternessPotential,
              ],
              name: "Allocated Budget",
              lineStyle: {
                type: [1, 2, 8, 2],
                color: "#215b38",
              },
              areaStyle: {
                color: "rgba(33, 91, 56, 0.5)",
              },
            },
          ],
        },
      ],
    };

    if (myChart.current) {
      myChart.current.setOption(option);
    }

    return () => {
      myChart.current && myChart.current.dispose();
    };
  }, [
    acidityPotential,
    sweetnessPotential,
    aromaPotential,
    bodyPotential,
    bitternessPotential,
  ]);

  return <div ref={chartRef} style={{ height: "400px", width: "100%" }} />;
};
