import React from "react";
import {
  Container,
  Grid2,
  Box,
  Stack,
  Typography,
  Chip,
  Avatar,
  SvgIcon,
} from "@mui/material";

import { Place, Business, Spa } from "@mui/icons-material";

import topImgStyle from "../../../assets/styles/views/productDetailPage.module.css";

import main_fourth_beanVariety_icon from "../../../assets/images/homeImages/main_fourth_beanVariety_icon.svg";
import main_fourth_processingMethod_icon from "../../../assets/images/homeImages/main_fourth_processingMethod_icon.svg";

export const ProductDetailTopArea = ({
  dataImageUrl, // 이미지
  dataTitle, // 타이틀
  dataBeanVariety, // 품종
  dataProcessingMethod, // 가공방법
  dataProductionCountry, // 원산지
  dataCompanyName, // 수입회사
  dataFarmName, // 농장
  dataProductionYear, // 생산년도
  dataCoffeeKey, // 키값
}) => {
  return (
    <Box
      sx={{
        mb: 2,
        p: 2,
        pl: 0,
        pr: 0,
        borderLeft: 0,
        borderRight: 0,
      }}
    >
      <Grid2 container spacing={5}>
        <Grid2 size={{ sm: 6, md: 4 }}>
          <Box
            sx={{
              maxHeight: "322px",
            }}
          >
            <img
              src={dataImageUrl}
              alt={dataTitle || "Default Image"}
              className={topImgStyle.pd_detail_top_img}
            />
          </Box>
        </Grid2>
        {/* 이미지 영역 */}
        <Grid2 size={{ sm: 6, md: 8 }}>
          <Typography component="h3" variant="h5" sx={{ fontWeight: "500" }}>
            {dataTitle}
          </Typography>
          <Box direction="row" sx={{ flexWrap: "wrap" }}>
            {Array.isArray(dataBeanVariety) &&
              dataBeanVariety.map((tag, index) => (
                <Chip
                  key={index}
                  avatar={
                    <Avatar
                      src={main_fourth_beanVariety_icon}
                      alt="Processing Method"
                    />
                  }
                  label={tag}
                  sx={{
                    fontSize: "0.75rem",
                    height: "24px",
                    "& .MuiChip-label": { pl: 1, pr: 1 },
                  }}
                />
              ))}

            <Chip
              avatar={
                <Avatar
                  src={main_fourth_processingMethod_icon}
                  alt="Processing Method"
                />
              }
              label={dataProcessingMethod}
              sx={{
                fontSize: "0.75rem",
                height: "24px",
                "& .MuiChip-label": { pl: 1, pr: 1 },
              }}
            />
          </Box>
          {/* 품종 및 가공방법 */}
          <Stack direction="row" gap={0.5}>
            <Typography
              gutterBottom
              variant="h6"
              component="div"
              sx={{
                display: "-webkit-box",
                overflow: "hidden",
                textOverflow: "ellipsis",
                WebkitBoxOrient: "vertical",
                wordWrap: "break-word",
                WebkitLineClamp: 1,
              }}
            >
              {dataProductionCountry}
            </Typography>
            <Place sx={{ color: "#B0B0B0", fontSize: "14px", mt: 0.25 }} />
          </Stack>
          {/* 원산지 */}
          <Stack direction="row" gap={0.5}>
            <Business sx={{ color: "#B0B0B0", fontSize: "14px", mt: 0.25 }} />
            <Typography
              sx={{
                fontSize: "0.8125rem",
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
              }}
              gutterBottom
              component="div"
            >
              {dataCompanyName}
            </Typography>
          </Stack>
          {/* 수입회사 */}
          <Stack direction="row" gap={0.5}>
            <Spa sx={{ color: "#B0B0B0", fontSize: "14px", mt: 0.25 }} />
            <Typography
              sx={{
                fontSize: "0.8125rem",
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
              }}
              gutterBottom
              component="div"
            >
              {dataFarmName}
            </Typography>
          </Stack>
          {/* 생산농장 */}
          <Stack direction="row" gap={0.5}>
            <Typography>Year</Typography>
            <Typography
              sx={{
                fontSize: "0.8125rem",
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
              }}
              gutterBottom
              component="div"
            >
              {dataProductionYear}
            </Typography>
          </Stack>
          {/* 생산년도 */}
        </Grid2>
        {/* 텍스트 영역 */}
      </Grid2>
    </Box>
  );
};
