import React from "react";
import flexBox from "../../assets/styles/common/flexBox.module.css";

import {
  Container,
  Grid2,
  Box,
  Stack,
  Typography,
  Card,
  CardActions,
  CardContent,
  CardMedia,
  Button,
  Chip,
  Divider,
  ButtonBase,
  Tooltip,
  Link,
  Avatar,
  SvgIcon,
} from "@mui/material";

import { Place, Business, Spa, KeyboardArrowRight } from "@mui/icons-material";

import main_fourth_beanVariety_icon from "../../assets/images/homeImages/main_fourth_beanVariety_icon.svg";
import main_fourth_processingMethod_icon from "../../assets/images/homeImages/main_fourth_processingMethod_icon.svg";

const SearchInfoCard = ({
  dataImageUrl,
  dataTitle,
  dataFarmName,
  dataProductionYear,
  dataBeanVariety,
  dataProcessingMethod,
  dataProductionCountry,
  dataTitleOnClick,
  dataImageOnClick,
  dataCompanyName,
  handleDetailClick,
}) => {
  return (
    <Grid2 size={{ xs: 12, sm: 4, md: 3 }}>
      <Card
        sx={{
          maxWidth: 345,
          minWidth: "auto",
          position: "relative",
          borderRadius: "0 40px 0 40px",
          p: 2,
        }}
      >
        <Box
          sx={{
            position: "relative",
            "&::after": {
              content: '""',
              position: "absolute",
              top: 0,
              bottom: 0,
              left: 0,
              right: 0,
              background: "rgba(0,0,0,0.25)",
              zIndex: 1,
            },
          }}
        >
          <CardMedia
            component="img"
            sx={{
              height: "100%",
              width: "auto",
              maxWidth: "100%",
              cursor: "pointer",
              zIndex: -1,
            }}
            image={dataImageUrl}
            alt={dataTitle || "Default Image"}
            onClick={dataImageOnClick}
          />
          <Typography
            onClick={dataTitleOnClick}
            gutterBottom
            variant="h6"
            component="div"
            sx={{
              zIndex: 2,
              position: "absolute",
              left: 0,
              top: 0,
              height: "100%",
              maxWidth: "100%",
              color: "#fff",
              overflow: "hidden",
              textOverflow: "ellipsis",
              WebkitBoxOrient: "vertical",
              wordWrap: "break-word",
              WebkitLineClamp: 3,
              p: 1.5,
              display: "flex",
              alignItems: "center",
            }}
          >
            {dataTitle}
          </Typography>
          {/* 생두 이름 */}
        </Box>
        <CardContent sx={{ p: 0, pt: 0, pb: 1.25 }}>
          <Box sx={{ gap: 1, width: "100%", mt: 1 }}>
            <Box className={flexBox.flexRowCenterSide}>
              <Stack direction="row" gap={0.5}>
                <Typography>Year</Typography>
                <Typography
                  sx={{
                    fontSize: "0.8125rem",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap",
                  }}
                  gutterBottom
                  component="div"
                >
                  {dataProductionYear}
                </Typography>
              </Stack>
              <Button
                onClick={handleDetailClick}
                sx={{
                  p: 1,
                  mt: 1.25,
                  minWidth: "0",
                  ml: 1,
                }}
                endIcon={<KeyboardArrowRight />}
              >
                detail
              </Button>
            </Box>
            <Stack direction="row" gap={0.5}>
              <Typography
                onClick={dataTitleOnClick}
                gutterBottom
                variant="h6"
                component="div"
                sx={{
                  display: "-webkit-box",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  WebkitBoxOrient: "vertical",
                  wordWrap: "break-word",
                  WebkitLineClamp: 1,
                }}
              >
                {dataProductionCountry}
              </Typography>
              <Place sx={{ color: "#B0B0B0", fontSize: "14px", mt: 0.25 }} />
            </Stack>
            <Stack direction="row" gap={0.5}>
              <Business sx={{ color: "#B0B0B0", fontSize: "14px", mt: 0.25 }} />
              <Typography
                sx={{
                  fontSize: "0.8125rem",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "nowrap",
                }}
                gutterBottom
                component="div"
              >
                {dataCompanyName}
              </Typography>
            </Stack>
            {/* 수입회사 */}
            <Stack direction="row" gap={0.5}>
              <Spa sx={{ color: "#B0B0B0", fontSize: "14px", mt: 0.25 }} />
              <Typography
                sx={{
                  fontSize: "0.8125rem",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "nowrap",
                }}
                gutterBottom
                component="div"
              >
                {dataFarmName}
              </Typography>
            </Stack>
            {/* 생산농장 */}
            <Box direction="row" sx={{ flexWrap: "wrap" }}>
              {Array.isArray(dataBeanVariety) &&
                dataBeanVariety.map((tag, index) => (
                  <Chip
                    key={index}
                    avatar={
                      <Avatar
                        src={main_fourth_beanVariety_icon}
                        alt="Processing Method"
                      />
                    }
                    label={tag}
                    sx={{
                      fontSize: "0.75rem",
                      height: "24px",
                      "& .MuiChip-label": { pl: 1, pr: 1 },
                    }}
                  />
                ))}

              <Chip
                avatar={
                  <Avatar
                    src={main_fourth_processingMethod_icon}
                    alt="Processing Method"
                  />
                }
                label={dataProcessingMethod}
                sx={{
                  fontSize: "0.75rem",
                  height: "24px",
                  "& .MuiChip-label": { pl: 1, pr: 1 },
                }}
              />
            </Box>
            {/* 품종 및 가공방법 */}
          </Box>
        </CardContent>
      </Card>
    </Grid2>
  );
};

export default SearchInfoCard;
