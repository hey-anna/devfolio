import React, { useState, useEffect } from "react";
import { Box, Button } from "@mui/material";
import { categories } from "../../constants/searchpageTexts";

export const CategoryButtons = ({
  selected,
  combinedCategories,
  onCategoryChange,
  setSelectedCategory,
}) => {
  const buttonStyle = (category) => ({
    backgroundColor: selected === category ? "#301D06" : "white",
    color: selected === category ? "white" : "#9FA0A1",
    border: `1px solid ${selected === category ? "white" : "#9FA0A1"}`,
    borderRadius: 50,
    "&:hover": {
      backgroundColor: "#301D06",
      borderColor: "white",
      color: "white",
    },
  });
  const handleCategorySelect = (category) => {
    const { key, value } = combinedCategories[category];
    onCategoryChange(key, value);
    setSelectedCategory(category);
  };

  return (
    <Box
      sx={{
        display: "flex",
        flexWrap: "wrap",
        gap: 1,
        justifyContent: "center",
      }}
    >
      {Object.keys(combinedCategories).map((category, index) => (
        <Button
          key={category}
          variant="outlined"
          onClick={() => handleCategorySelect(category)}
          sx={buttonStyle(category)}
        >
          {category}
        </Button>
      ))}
    </Box>
  );
};
