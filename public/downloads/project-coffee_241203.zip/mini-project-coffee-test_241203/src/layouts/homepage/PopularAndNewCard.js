import React, { useEffect, useState } from "react";
import flexBox from "../../assets/styles/common/flexBox.module.css";
import {
  Box,
  Typography,
  Container,
  Grid2,
  Stack,
  Card,
  CardActions,
  CardContent,
  CardMedia,
  Button,
  Chip,
  Avatar,
} from "@mui/material";
import { Add, Spa, Place, Business, ArrowDropUp } from "@mui/icons-material";
import main_fourth_beanVariety_icon from "../../assets/images/homeImages/main_fourth_beanVariety_icon.svg";
import main_fourth_processingMethod_icon from "../../assets/images/homeImages/main_fourth_processingMethod_icon.svg";

export default function PopularAndNewCard({
  dataImageUrl,
  dataTitle,
  dataFarmName,
  dataProductionYear, // 생산년도
  dataBeanVariety,
  dataProcessingMethod, // 가공방법
  dataProductionCountry, // 원산지
  dataTitleOnClick, // 타이틀 클릭시 상세 페이지
  dataImageOnClick, // 이미지 클릭시 상세 페이지
  dataCompanyName,
}) {
  return (
    <Grid2 item size={{ xs: 12, sm: 4, md: 3 }}>
      <Card
        sx={{
          maxWidth: 345,
          minWidth: "auto",
          position: "relative",
          borderRadius: "0 40px 0 40px",
        }}
      >
        <Box>
          <CardMedia
            component="img"
            sx={{
              height: "100%",
              width: "auto",
              maxWidth: "100%",
              cursor: "pointer",
            }}
            image={dataImageUrl}
            alt={dataTitle || "Default Image"}
            onClick={dataImageOnClick}
          />
        </Box>

        <CardContent sx={{ p: 1.5, pt: 0, pb: "14px !important" }}>
          <Box sx={{ gap: 1, width: "100%", mt: 1 }}>
            <Typography
              onClick={dataTitleOnClick}
              gutterBottom
              variant="h6"
              component="div"
              sx={{
                display: "-webkit-box",
                overflow: "hidden",
                textOverflow: "ellipsis",
                WebkitBoxOrient: "vertical",
                wordWrap: "break-word",
                WebkitLineClamp: 1,
              }}
            >
              {dataTitle}
            </Typography>
            {/* 생두 이름 */}
            <Box direction="row" sx={{ flexWrap: "wrap" }}>
              {Array.isArray(dataBeanVariety) &&
                dataBeanVariety.map((tag, index) => (
                  <Chip
                    key={index}
                    avatar={
                      <Avatar
                        src={main_fourth_beanVariety_icon}
                        alt="Processing Method"
                      />
                    }
                    label={tag}
                    sx={{
                      fontSize: "0.75rem",
                      height: "24px",
                      "& .MuiChip-label": { pl: 1, pr: 1 },
                    }}
                  />
                ))}
              <img src={main_fourth_processingMethod_icon} />
              <Chip
                avatar={
                  <Avatar
                    src={main_fourth_processingMethod_icon}
                    alt="Processing Method"
                  />
                }
                label={dataProcessingMethod}
                sx={{
                  fontSize: "0.75rem",
                  height: "24px",
                  "& .MuiChip-label": { pl: 1, pr: 1 },
                }}
              />
            </Box>
            {/* 품종 및 가공방법 */}
            <Stack direction="row" gap={0.5}>
              <Typography
                onClick={dataTitleOnClick}
                gutterBottom
                variant="h6"
                component="div"
                sx={{
                  display: "-webkit-box",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  WebkitBoxOrient: "vertical",
                  wordWrap: "break-word",
                  WebkitLineClamp: 1,
                }}
              >
                {dataProductionCountry}
              </Typography>
              <Stack direction="row" gap={0.5}>
                <Place sx={{ color: "#B0B0B0", fontSize: "14px", mt: 0.25 }} />
                <Typography
                  sx={{
                    fontSize: "0.8125rem",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap",
                  }}
                  gutterBottom
                  component="div"
                >
                  {dataCompanyName}
                </Typography>
              </Stack>
            </Stack>
            <Stack direction="row" gap={0.5}>
              <Business sx={{ color: "#B0B0B0", fontSize: "14px", mt: 0.25 }} />
              <Typography
                sx={{
                  fontSize: "0.8125rem",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "nowrap",
                }}
                gutterBottom
                component="div"
              >
                {dataCompanyName}
              </Typography>
            </Stack>
            {/* 수입회사 */}
            <Stack direction="row" gap={0.5}>
              <Spa sx={{ color: "#B0B0B0", fontSize: "14px", mt: 0.25 }} />
              <Typography
                sx={{
                  fontSize: "0.8125rem",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "nowrap",
                }}
                gutterBottom
                component="div"
              >
                {dataFarmName}
              </Typography>
            </Stack>
            {/* 생산농장 */}
            <Box className={flexBox.flexRowCenterSide}>
              <Stack direction="row" gap={0.5}>
                <Typography>Year</Typography>
                <Typography
                  sx={{
                    fontSize: "0.8125rem",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap",
                  }}
                  gutterBottom
                  component="div"
                >
                  {dataProductionYear}
                </Typography>
              </Stack>
              <Button
                sx={{
                  p: 1,
                  mt: 1.25,
                  minWidth: "0",
                  ml: 1,
                  backgroundColor: "#003399",
                }}
              >
                <Add
                  sx={{
                    color: "#fff",
                    fontSize: "1.5rem",
                  }}
                />
              </Button>
            </Box>
          </Box>
        </CardContent>
      </Card>
    </Grid2>
  );
}
