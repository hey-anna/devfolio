import React from "react";
import { Grid2 } from "@mui/material";
import image1 from "../../assets/images/homeImages/main_second_greenBean_process01.svg";
import image2 from "../../assets/images/homeImages/main_second_greenBean_process02.svg";
import image3 from "../../assets/images/homeImages/main_second_greenBean_process03.svg";
import image4 from "../../assets/images/homeImages/main_second_greenBean_process04.svg";
import image5 from "../../assets/images/homeImages/main_second_greenBean_process05.svg";

const images = [
  {
    src: image1,
    alt: "생두 처리 공정 첫번째 이미지",
    style: { borderRadius: "0 80px 0 80px" },
  },
  {
    src: image2,
    alt: "생두 처리 공정 두번째 이미지",
    style: { borderRadius: "80px 0 80px 0" },
  },
  {
    src: image3,
    alt: "생두 처리 공정 세번째 이미지",
    style: { borderRadius: "0 80px 0 80px" },
  },
  {
    src: image4,
    alt: "생두 처리 공정 네번째 이미지",
    style: { borderRadius: "80px 0 80px 0" },
  },
  {
    src: image5,
    alt: "생두 처리 공정 다섯번째 이미지",
    style: { borderRadius: "0 80px 0 80px" },
  },
];

export const ProcessImageCard = () => {
  return (
    <Grid2 container spacing={2} columns={{ xs: 4, sm: 8, md: 12 }}>
      {images.map((image, index) => (
        <Grid2 size={2.4} key={index}>
          <img
            src={image.src}
            alt={image.alt}
            style={{ width: "100%", height: "auto", ...image.style }}
          />
        </Grid2>
      ))}
    </Grid2>
  );
};
