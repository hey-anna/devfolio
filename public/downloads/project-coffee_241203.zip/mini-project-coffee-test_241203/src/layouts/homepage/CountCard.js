import React from "react";
import { Grid2, Box, Stack, Divider, Typography } from "@mui/material";
import { Add } from "@mui/icons-material";
import flexBox from "../../assets/styles/common/flexBox.module.css";
import { COUNT_TEXT } from "../../constants/homepageTexts";

// 임시 숫자 카운트 데이터
const countData = {
  today: 30,
  thisWeek: 120,
  thisMonth: 500,
  beforeThreeMonths: 1500,
};

export const CountCard = () => {
  return (
    <Grid2 container spacing={4} columns={{ xs: 4, sm: 8, md: 12 }}>
      {Object.keys(countData).map((key, index) => (
        <Grid2 size={3} key={key}>
          <Box className={flexBox.flexRowCenter} sx={{ position: "relative" }}>
            <Box className={flexBox.flexColumn}>
              <Stack gap={0.5} direction="row" className={flexBox.alignCenter}>
                <Typography variant="h3">{countData[key]}</Typography>
                <Add sx={{ fontSize: "2.125rem" }} />
              </Stack>
              <Typography align="center">{COUNT_TEXT[key]}</Typography>
            </Box>
            {index < Object.keys(countData).length - 1 && (
              <Divider
                orientation="vertical"
                variant="middle"
                flexItem
                sx={{
                  position: "absolute",
                  right: "-0.5px",
                  top: 0,
                  bottom: 0,
                }}
              />
            )}
          </Box>
        </Grid2>
      ))}
    </Grid2>
  );
};
