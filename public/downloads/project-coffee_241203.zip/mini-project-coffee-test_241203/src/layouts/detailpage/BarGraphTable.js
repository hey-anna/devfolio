import React from "react";
import {
  Box,
  Table,
  TableHead,
  TableBody,
  TableCell,
  TableContainer,
  TableRow,
  Paper,
} from "@mui/material";
import { barGraphInfo } from "../../constants/detailpageTexts";

function BarGraphTable() {
  const renderMultilineText = (text) => {
    return text.split("\n").map((line, index) => (
      <span key={index}>
        {line}
        {index < text.split("\n").length - 1 && <br />}
      </span>
    ));
  };
  return (
    <Paper sx={{ width: "100%", overflow: "hidden" }}>
      <TableContainer sx={{ width: "100%", height: "auto" }}>
        <Table
          size="small"
          sx={{
            width: "100%",
            height: "auto",
            minWidth: "unset",
          }}
        >
          <TableBody>
            {barGraphInfo.map((row, index) => (
              <TableRow key={index}>
                <TableCell
                  sx={{
                    width: "20%",
                    fontWeight: "bold",
                    backgroundColor: "#EFF2F4",
                    fontSize: "0.75rem",
                  }}
                >
                  {renderMultilineText(row.item)}
                </TableCell>
                <TableCell
                  sx={{
                    fontSize: "0.75rem",
                    whiteSpace: "normal",
                    wordWrap: "break-word",
                  }}
                >
                  {renderMultilineText(row.info)}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Paper>
  );
}

export default BarGraphTable;
