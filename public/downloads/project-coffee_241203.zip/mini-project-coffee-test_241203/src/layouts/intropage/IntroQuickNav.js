import React, { useState, useEffect } from "react";
import { Box, Button, Stack, Typography } from "@mui/material";
import { borderColor, styled } from "@mui/system";
import CircleIcon from "@mui/icons-material/Circle";

const CustomButton = styled(Button)({
  borderRadius: "15px",
  justifyContent: "flex-start",
  backgroundColor: "transparent",
  boxShadow: "none",
  color: "#003399",
  "&:hover": {
    backgroundColor: "transparent",
    boxShadow: "none",
  },
});
const IconWrapper = styled(Box)(({ theme, active }) => ({
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  borderRadius: "50%",
  width: theme.spacing(5),
  height: theme.spacing(5),
  border: active ? "0.5px solid #003399" : "none",
}));

const IntroQuickNav = ({ sections, activeSection }) => {
  const [selectedId, setSelectedId] = useState(sections[0]?.id);
  const scrollToSection = (id) => {
    const section = document.getElementById(id);
    if (section) {
      section.scrollIntoView({ behavior: "smooth", block: "start" });
      setSelectedId(id);
    }
  };
  useEffect(() => {
    if (sections.length > 0) {
      setSelectedId(sections[0].id);
    }
  }, [sections]);
  return (
    <Box sx={{ position: "fixed", top: 150, left: 30, zIndex: 1000 }}>
      <Stack direction="column" spacing={0}>
        {sections.map((section, index) => (
          <CustomButton
            key={section.id}
            variant="contained"
            onClick={() => scrollToSection(section.id)}
            className={selectedId === section.id ? "active" : ""}
          >
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 0.5,
              }}
            >
              <IconWrapper active={activeSection === section.id}>
                <CircleIcon sx={{ fontSize: "8px" }} />
              </IconWrapper>

              <Typography
                sx={{
                  flexGrow: 1,
                  padding: "8px 12px",
                  borderRadius: "20px",
                  backgroundColor: "rgba(255, 255, 255, 0.5)",

                  border:
                    activeSection === section.id
                      ? "0.5px solid #003399"
                      : "none",
                  marginLeft: "8px",
                }}
              >
                {section.label}
              </Typography>
            </Box>
          </CustomButton>
        ))}
      </Stack>
    </Box>
  );
};

export default IntroQuickNav;
