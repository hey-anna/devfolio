import React, { useEffect, useState } from "react";
import { styled } from "@mui/material/styles";
import {
  Typography,
  Grid2,
  Card,
  Paper,
  CardActionArea,
  CardContent,
  CardMedia,
  Box,
} from "@mui/material";

const Item = styled(Paper)(({ theme }) => ({
  ...theme.typography.body2,
  textAlign: "center",
  display: "flex",
  flexDirection: "column",
  backgroundColor: "#EFF2F4",
  position: "relative",
  height: "100%",
  aspectRatio: "1 / 1",
  [theme.breakpoints.down("md")]: {
    aspectRatio: "auto",
  },
}));

function StatisticsCard({ card }) {
  const [fontSize, setFontSize] = useState("3.75rem");
  const formatNumber = (num) => {
    return new Intl.NumberFormat("ko-KR").format(num);
  };

  useEffect(() => {
    const textLength = card.date?.toString().length || 0;
    let newSize = "3.75rem";
    if (textLength < 6) {
      newSize = `calc(3.75rem - ${textLength * 0.1}rem)`;
    } else if (textLength < 8) {
      newSize = "2.77rem";
    } else if (textLength < 9) {
      newSize = "2.55rem";
    } else if (textLength < 10) {
      newSize = "2.36rem";
    } else {
      newSize = "2rem";
    }

    setFontSize(newSize);
  }, [card.date]);

  return (
    <Grid2 size={{ xs: 12, sm: 4, md: 3 }}>
      <Item>
        <Grid2
          sx={{
            height: "inherit",
            "& .MuiGrid-root": {},
            "& .MuiPaper-root": {
              background: "none",
              border: "0",
              boxShadow: "0",
              height: "inherit",
            },
          }}
        >
          <Card>
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                p: 3,

                height: "inherit",
              }}
            >
              <CardContent
                sx={{
                  p: 0,
                  pb: "0 !important",

                  height: "inherit",
                }}
              >
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 1,
                    p: 0,
                    height: "inherit",
                  }}
                >
                  <Typography
                    component="h3"
                    variant="h5"
                    sx={{
                      textAlign: "left",
                    }}
                  >
                    {card.title}
                  </Typography>
                  <Box
                    sx={{
                      textAlign: "right",
                      height: "inherit",
                      display: "flex",
                      flexWrap: "wrap",
                      justifyContent: "flex-end",
                      alignItems: "baseline",
                      alignContent: "flex-end",
                    }}
                  >
                    {card.date && (
                      <Typography
                        component="subtitle1"
                        variant="h2"
                        sx={{
                          color: "#468ECD",
                          fontWeight: "600",
                          fontFamily: "sans-serif",
                          fontSize: {},
                          fontSize: fontSize,
                        }}
                      >
                        {formatNumber(card.date)}
                      </Typography>
                    )}
                    <Typography
                      component="subtitle1"
                      sx={{
                        color: "#468ECD",
                        "& .MuiTypography-root": { textAlign: "right" },
                      }}
                      variant="h5"
                      type="number"
                    >
                      {card.description}
                    </Typography>
                  </Box>
                </Box>
              </CardContent>
            </Box>
          </Card>
        </Grid2>
      </Item>
    </Grid2>
  );
}

export default StatisticsCard;
