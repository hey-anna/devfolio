import { createTheme } from "@mui/material/styles";

const baseTheme = createTheme({
  palette: {
    primary: {
      main: "#333",
    },
    secondary: {
      main: "#EEFD53",
    },
    tertiary: {
      main: "#468ECD",
    },
    quaternary: {
      main: "#0009",
    },
    error: {
      main: "#DA1E28",
    },
  },

  typography: {
    fontFamily: [
      "Noto Sans KR",
      "sans-serif",
      "-apple-system",
      "BlinkMacSystemFont",
      "Segoe UI",
      "Roboto",
      "Oxygen",
      "Ubuntu",
      "Cantarell",
      "Fira Sans",
      "Droid Sans",
      "Helvetica Neue",
    ].join(","),
  },

  components: {
    MuiCssBaseline: {
      styleOverrides: {
        "*": {
          boxSizing: "border-box",
          margin: 0,
          padding: 0,
        },
        html: {
          height: "100%",

          width: "100%",
        },
        body: {
          height: "100%",
          width: "100%",
        },
        "#root": {
          width: "100%",
          height: "100vh",
          display: "flex",
          flexDirection: "column",
        },

        table: {
          minWidth: 1080,
        },
        P: {
          fontFamily: "Noto Sans KR !important",
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        root: ({ ownerState }) => ({
          textTransform: "none",
          ...(ownerState.variant === "contained" &&
            ownerState.color === "primary" && {
              backgroundColor: "#202020",
              color: "#fff",
            }),
        }),
      },
    },
    MuiTablePagination: {
      styleOverrides: {
        root: {
          margin: "0 20px",
          borderRadius: 4,
          "&:last-child": {
            padding: "20px 0",
          },
        },
        spacer: {
          flex: "1 1 100%",
        },
      },
    },
    MuiContainer: {
      styleOverrides: {
        root: {
          paddingLeft: 0,
          paddingRight: 0,
          "@media (min-width: 600px)": {
            paddingLeft: 0,
            paddingRight: 0,
          },
        },
      },
    },
  },
});

export default baseTheme;
