import React from "react";
import { createBrowserRouter } from "react-router-dom";
import App from "../App";
import HomePage from "../views/HomePage";
import IntroPage from "../views/IntroPage";
import SearchPage from "../views/SearchPage/SearchPage";
import { ProductDetailPage } from "../views/SearchPage/ProductDetailPage";
import MyPage from "../views/MyPage";
import StatisticsPage from "../views/StatisticsPage";
import LoginPage from "../auth/LoginPage";
import ErrorPage from "../views/errors/ErrorPage";
import AuthGuard from "../auth/AuthGuard";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    errorElement: <ErrorPage />,
    children: [
      {
        index: true,
        path: "",
        element: <HomePage />,
      },
      {
        path: "intro",
        element: <IntroPage />,
      },
      {
        path: "search",
        element: <SearchPage />,
      },
      {
        path: "detail/:coffee_key_id",
        element: <ProductDetailPage />,
      },
      {
        path: "mypage",
        element: (
          <AuthGuard>
            <MyPage />
          </AuthGuard>
        ),
      },
      {
        path: "statistics",
        element: <StatisticsPage />,
      },
      {
        path: "login",
        element: <LoginPage />,
      },
    ],
  },
]);
